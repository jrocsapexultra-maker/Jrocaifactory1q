//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BxrUVmRJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/bible",
			"/characters",
			"/continuity",
			"/factory",
			"/lettering",
			"/pages",
			"/publish",
			"/qc",
			"/world"
		],
		preloads: ["/assets/index-Q6YMnBSH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Q6YMnBSH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BygZKqmX.js",
			"/assets/shell-CXzDcupF.js",
			"/assets/badge-CwQodqhh.js",
			"/assets/progress-DIfdVs8F.js",
			"/assets/status-D4-mtdn0.js"
		]
	},
	"/bible": {
		filePath: "/workspace/src/routes/bible.tsx",
		children: void 0,
		preloads: [
			"/assets/bible-vmNs8A8H.js",
			"/assets/ai-oDyDBMlM.js",
			"/assets/shell-CXzDcupF.js",
			"/assets/field-L7LC9Brq.js"
		]
	},
	"/characters": {
		filePath: "/workspace/src/routes/characters.tsx",
		children: void 0,
		preloads: [
			"/assets/characters-B2E7gNtw.js",
			"/assets/shell-CXzDcupF.js",
			"/assets/field-L7LC9Brq.js"
		]
	},
	"/continuity": {
		filePath: "/workspace/src/routes/continuity.tsx",
		children: void 0,
		preloads: [
			"/assets/continuity-DIXFXSEu.js",
			"/assets/shell-CXzDcupF.js",
			"/assets/continuity-OP0FSq7Q.js",
			"/assets/field-L7LC9Brq.js"
		]
	},
	"/factory": {
		filePath: "/workspace/src/routes/factory.tsx",
		children: void 0,
		preloads: [
			"/assets/factory-DE8Bc0d0.js",
			"/assets/shell-CXzDcupF.js",
			"/assets/badge-CwQodqhh.js",
			"/assets/progress-DIfdVs8F.js"
		]
	},
	"/lettering": {
		filePath: "/workspace/src/routes/lettering.tsx",
		children: void 0,
		preloads: [
			"/assets/lettering-BfcBL8fI.js",
			"/assets/shell-CXzDcupF.js",
			"/assets/field-L7LC9Brq.js"
		]
	},
	"/pages": {
		filePath: "/workspace/src/routes/pages.tsx",
		children: ["/pages/$pageId"],
		preloads: [
			"/assets/pages-Cz0CvpiE.js",
			"/assets/shell-CXzDcupF.js",
			"/assets/badge-CwQodqhh.js",
			"/assets/status-D4-mtdn0.js"
		]
	},
	"/publish": {
		filePath: "/workspace/src/routes/publish.tsx",
		children: void 0,
		preloads: ["/assets/publish-5jGEtpoI.js", "/assets/shell-CXzDcupF.js"]
	},
	"/qc": {
		filePath: "/workspace/src/routes/qc.tsx",
		children: void 0,
		preloads: [
			"/assets/qc-BF3_LDMh.js",
			"/assets/shell-CXzDcupF.js",
			"/assets/badge-CwQodqhh.js"
		]
	},
	"/world": {
		filePath: "/workspace/src/routes/world.tsx",
		children: void 0,
		preloads: [
			"/assets/world-DvfrLOwe.js",
			"/assets/shell-CXzDcupF.js",
			"/assets/field-L7LC9Brq.js"
		]
	},
	"/pages/$pageId": {
		filePath: "/workspace/src/routes/pages.$pageId.tsx",
		children: void 0,
		preloads: [
			"/assets/pages._pageId-c6faQrMW.js",
			"/assets/ai-oDyDBMlM.js",
			"/assets/continuity-OP0FSq7Q.js",
			"/assets/field-L7LC9Brq.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
