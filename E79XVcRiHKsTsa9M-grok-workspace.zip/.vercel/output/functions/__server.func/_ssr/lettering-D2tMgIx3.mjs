import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useFactory, n as StudioShell, t as Button } from "./shell-DIXOIZBR.mjs";
import { n as Input, t as Field } from "./field-C0C5rtLF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lettering-D2tMgIx3.js
var import_jsx_runtime = require_jsx_runtime();
function LetteringView() {
	const universe = useFactory((s) => s.universe);
	const selectedPageId = useFactory((s) => s.selectedPageId);
	const selectPage = useFactory((s) => s.selectPage);
	const updatePanel = useFactory((s) => s.updatePanel);
	const toggleQc = useFactory((s) => s.toggleQc);
	const page = universe.pages.find((p) => p.id === selectedPageId) ?? universe.pages[0];
	if (!page) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[220px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "grid h-fit gap-1",
			children: universe.pages.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => selectPage(p.id),
				className: `h-11 rounded-sm px-3 text-left font-mono text-sm ${p.id === page.id ? "bg-elevated" : "text-muted hover:bg-elevated"}`,
				children: [
					String(p.number).padStart(3, "0"),
					" ",
					p.title
				]
			}, p.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Lettering Studio"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Balloons, captions, SFX. Placement is stored per panel."
				})] }),
				page.panels.map((panel) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "grid gap-3 rounded-xl border border-border bg-surface p-4 md:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `Panel ${panel.number} dialogue`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: panel.dialogue,
								onChange: (e) => updatePanel(page.id, panel.id, { dialogue: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Caption",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: panel.caption,
								onChange: (e) => updatePanel(page.id, panel.id, { caption: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "SFX",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: panel.sfx,
								onChange: (e) => updatePanel(page.id, panel.id, { sfx: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Balloon X / Y %",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: panel.balloonX,
									onChange: (e) => updatePanel(page.id, panel.id, { balloonX: Number(e.target.value) })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: panel.balloonY,
									onChange: (e) => updatePanel(page.id, panel.id, { balloonY: Number(e.target.value) })
								})]
							})
						})
					]
				}, panel.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => toggleQc(page.id, "lettering"),
					children: page.qc.lettering ? "Lettering approved" : "Mark lettering approved"
				})
			]
		})]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LetteringView, {}) });
}
//#endregion
export { Page as component };
