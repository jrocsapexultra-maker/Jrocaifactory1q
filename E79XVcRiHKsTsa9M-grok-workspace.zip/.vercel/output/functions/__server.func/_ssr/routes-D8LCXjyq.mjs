import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useFactory, i as pipelinePercents, n as StudioShell, t as Button } from "./shell-DIXOIZBR.mjs";
import { t as Badge } from "./badge-Bxwz08H4.mjs";
import { t as Meter } from "./progress-P77548kW.mjs";
import { n as statusTone, t as statusMark } from "./status-BeUKTx8u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D8LCXjyq.js
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const universe = useFactory((s) => s.universe);
	const selectPage = useFactory((s) => s.selectPage);
	const p = pipelinePercents(universe);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.2em] text-muted",
						children: "Comic Universe"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl tracking-tight md:text-5xl",
						children: universe.bible.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-muted leading-normal",
						children: universe.bible.logline
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-6 rounded-xl border border-border bg-surface p-5 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wide text-muted",
						children: universe.volume.issue
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: universe.volume.title
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "ink",
						children: "Free model router"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 md:grid-cols-2 lg:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Story",
							value: p.story
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Storyboard",
							value: p.board
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Artwork",
							value: p.art
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Continuity",
							value: p.cont
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Lettering",
							value: p.letter
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Approved",
							value: p.pub
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Pages"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-6",
					children: universe.pages.map((page) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/pages/$pageId",
						params: { pageId: page.id },
						onClick: () => selectPage(page.id),
						className: "flex h-16 flex-col items-center justify-center rounded-md border border-border bg-elevated text-center transition-colors hover:border-accent",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-sm tabular-nums",
							children: String(page.number).padStart(3, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							tone: statusTone(page.status),
							className: "mt-1 h-5 border-0 px-1 text-[10px]",
							children: [
								statusMark(page.status),
								" ",
								page.status
							]
						})]
					}, page.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-4 md:grid-cols-3",
				children: universe.characters.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/characters",
					className: "overflow-hidden rounded-xl border border-border bg-surface",
					children: [c.frontRef ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: c.frontRef,
						alt: "",
						className: "h-56 w-full object-cover object-top"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wide text-muted",
							children: c.role
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-xl",
							children: c.name
						})]
					})]
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/pages",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Generate next page" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/factory",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							children: "Batch generate"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/continuity",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							children: "Continuity"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/publish",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							children: "Export"
						})
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {}) });
}
//#endregion
export { Home as component };
