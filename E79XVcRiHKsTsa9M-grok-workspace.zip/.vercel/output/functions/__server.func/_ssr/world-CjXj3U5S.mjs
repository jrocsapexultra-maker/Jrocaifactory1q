import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useFactory, n as StudioShell } from "./shell-DIXOIZBR.mjs";
import { n as Input, r as Textarea, t as Field } from "./field-C0C5rtLF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/world-CjXj3U5S.js
var import_jsx_runtime = require_jsx_runtime();
function WorldView() {
	const universe = useFactory((s) => s.universe);
	const upsertLocation = useFactory((s) => s.upsertLocation);
	const upsertProp = useFactory((s) => s.upsertProp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl tracking-tight",
				children: "Locations & Props"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "World DNA injected into every panel that visits these places."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Location DNA"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 md:grid-cols-2",
					children: universe.locations.map((loc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "overflow-hidden rounded-xl border border-border bg-surface",
						children: [loc.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: loc.image,
							alt: "",
							className: "h-40 w-full object-cover"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Name",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: loc.name,
										onChange: (e) => upsertLocation({
											...loc,
											name: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Atmosphere",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										value: loc.atmosphere,
										onChange: (e) => upsertLocation({
											...loc,
											atmosphere: e.target.value
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Lighting",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: loc.lighting,
										onChange: (e) => upsertLocation({
											...loc,
											lighting: e.target.value
										})
									})
								})
							]
						})]
					}, loc.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Prop library"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3",
					children: universe.props.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "grid gap-3 rounded-xl border border-border bg-surface p-4 md:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: p.name,
									onChange: (e) => upsertProp({
										...p,
										name: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "State",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: p.state,
									onChange: (e) => upsertProp({
										...p,
										state: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Description",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: p.description,
									onChange: (e) => upsertProp({
										...p,
										description: e.target.value
									})
								})
							})
						]
					}, p.id))
				})]
			})
		]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldView, {}) });
}
//#endregion
export { Page as component };
