import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useFactory, n as StudioShell, t as Button } from "./shell-DIXOIZBR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/publish-DusEKbyO.js
var import_jsx_runtime = require_jsx_runtime();
function PublishView() {
	const universe = useFactory((s) => s.universe);
	const resetUniverse = useFactory((s) => s.resetUniverse);
	function exportJson() {
		const blob = new Blob([JSON.stringify(universe, null, 2)], { type: "application/json" });
		const a = document.createElement("a");
		a.href = URL.createObjectURL(blob);
		a.download = `${universe.name.toLowerCase()}-vol01.json`;
		a.click();
	}
	function exportWeb() {
		window.print();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl tracking-tight",
				children: "Publishing"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "PNG pages, print, web edition, and a JSON archive for CBZ assembly."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3 no-print",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: exportWeb,
						children: "Print / PDF"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: exportJson,
						children: "Download JSON / CBZ source"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: resetUniverse,
						children: "Reset universe"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "grid gap-8",
				children: universe.pages.map((page) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "break-inside-avoid overflow-hidden rounded-xl border border-border bg-surface",
					children: [page.finalImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: page.finalImage,
						alt: "",
						className: "w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2 p-6",
						children: page.panels.map((panel) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-border p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-xs text-muted",
									children: ["Panel ", panel.number]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: panel.action }),
								panel.dialogue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 italic",
									children: panel.dialogue
								}) : null
							]
						}, panel.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between p-3 text-xs uppercase tracking-wide text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							universe.name,
							" · ",
							String(page.number).padStart(3, "0")
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: page.type })]
					})]
				}, page.id))
			})
		]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublishView, {}) });
}
//#endregion
export { Page as component };
