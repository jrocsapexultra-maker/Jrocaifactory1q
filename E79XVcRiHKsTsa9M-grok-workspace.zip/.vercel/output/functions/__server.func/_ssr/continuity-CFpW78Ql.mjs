import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { a as useFactory, n as StudioShell, t as Button } from "./shell-DIXOIZBR.mjs";
import { n as Input, t as Field } from "./field-C0C5rtLF.mjs";
import { t as buildContinuityState } from "./continuity-D7MjaFUF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/continuity-CFpW78Ql.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FIELDS = [
	"costume",
	"injuries",
	"weapons",
	"props",
	"location",
	"weather",
	"timeOfDay",
	"damage",
	"position"
];
function ContinuityView() {
	const universe = useFactory((s) => s.universe);
	const addEvent = useFactory((s) => s.addEvent);
	const [pageNumber, setPageNumber] = (0, import_react.useState)(5);
	const [field, setField] = (0, import_react.useState)("costume");
	const [characterId, setCharacterId] = (0, import_react.useState)("watcher");
	const [value, setValue] = (0, import_react.useState)("");
	const state = (0, import_react.useMemo)(() => buildContinuityState(universe.events, pageNumber), [universe.events, pageNumber]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Continuity Guardian"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Canonical state for any page, built from every prior event."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Inspect page",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 1,
						max: universe.volume.pageCount,
						value: pageNumber,
						onChange: (e) => setPageNumber(Number(e.target.value))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid gap-3 rounded-xl border border-border bg-surface p-5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Location",
							v: state.location
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Weather",
							v: state.weather
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Time",
							v: state.timeOfDay
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Damage",
							v: state.damage
						}),
						universe.characters.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-border pt-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: c.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-muted",
									children: ["Costume: ", state.costume[c.id] || c.costume]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-muted",
									children: ["Injury: ", state.injuries[c.id] || "none"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-muted",
									children: ["Weapon: ", state.weapons[c.id] || c.weapons]
								})
							]
						}, c.id))
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Log an event"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Field",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-11 rounded-sm border border-border bg-bg px-3 text-sm",
						value: field,
						onChange: (e) => setField(e.target.value),
						children: FIELDS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: f,
							children: f
						}, f))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Character",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-11 rounded-sm border border-border bg-bg px-3 text-sm",
						value: characterId,
						onChange: (e) => setCharacterId(e.target.value),
						children: universe.characters.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Value",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value,
						onChange: (e) => setValue(e.target.value),
						placeholder: "Damaged V2"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						if (!value.trim()) return;
						addEvent({
							pageNumber,
							field,
							value,
							characterId
						});
						setValue("");
					},
					children: "Record event"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "grid gap-2",
					children: universe.events.slice().sort((a, b) => a.pageNumber - b.pageNumber).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-md border border-border bg-surface px-3 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-ink",
								children: ["p", String(e.pageNumber).padStart(2, "0")]
							}),
							" ",
							e.field,
							" · ",
							e.value
						]
					}, e.id))
				})
			]
		})]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-right",
			children: v || "—"
		})]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContinuityView, {}) });
}
//#endregion
export { Page as component };
