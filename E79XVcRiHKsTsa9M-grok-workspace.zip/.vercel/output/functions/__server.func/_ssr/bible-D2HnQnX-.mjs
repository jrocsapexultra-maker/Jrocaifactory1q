import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { a as useFactory, n as StudioShell, t as Button } from "./shell-DIXOIZBR.mjs";
import { n as Input, r as Textarea, t as Field } from "./field-C0C5rtLF.mjs";
import { r as writeStory } from "./ai-D7V2BqXi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bible-D2HnQnX-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BibleView() {
	const universe = useFactory((s) => s.universe);
	const setStory = useFactory((s) => s.setStory);
	const updateBible = useFactory((s) => s.updateBible);
	const updateStyle = useFactory((s) => s.updateStyle);
	const textModel = useFactory((s) => s.textModel);
	const [tab, setTab] = (0, import_react.useState)("universe");
	const [instruction, setInstruction] = (0, import_react.useState)("Tighten chapter two so Nyx arrives earlier.");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function expandStory() {
		setBusy(true);
		const res = await writeStory({ data: {
			bible: `${universe.bible.premise}\nRules:\n${universe.bible.rules.join("\n")}`,
			current: universe.story,
			instruction,
			model: textModel
		} });
		setBusy(false);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		setStory(res.text);
		toast.success(`Story rewritten with ${res.model}`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl tracking-tight",
				children: "Universe Bible"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Lore, story, and the style lock for every generation."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"universe",
					"story",
					"style"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: tab === t ? "primary" : "outline",
					size: "sm",
					onClick: () => setTab(t),
					children: t
				}, t))
			}),
			tab === "universe" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 rounded-xl border border-border bg-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Logline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: universe.bible.logline,
							onChange: (e) => updateBible({ logline: e.target.value })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Premise",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: universe.bible.premise,
							onChange: (e) => updateBible({ premise: e.target.value })
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-border bg-surface p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 font-display text-xl",
								children: "Rules"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid gap-2 text-sm leading-normal text-muted",
								children: universe.bible.rules.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "border-l-2 border-ink pl-3",
									children: r
								}, r))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-border bg-surface p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 font-display text-xl",
								children: "Timeline"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "grid gap-2",
								children: universe.bible.timeline.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-4 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-ink",
										children: t.year
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: t.event
									})]
								}, t.year))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-border bg-surface p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mb-3 font-display text-xl",
								children: "Factions"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid gap-3",
								children: universe.bible.factions.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: f.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: f.note
								})] }, f.name))
							})]
						})
					]
				})]
			}) : null,
			tab === "story" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Story bible",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							className: "min-h-56",
							value: universe.story,
							onChange: (e) => setStory(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Director instruction",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: instruction,
							onChange: (e) => setInstruction(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: expandStory,
						disabled: busy,
						children: busy ? "Writing with free model…" : "Rewrite with free story model"
					})
				]
			}) : null,
			tab === "style" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [
					["name", universe.style.name],
					["line", universe.style.line],
					["color", universe.style.color],
					["lighting", universe.style.lighting],
					["camera", universe.style.camera],
					["lettering", universe.style.lettering],
					["references", universe.style.references]
				].map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: key,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value,
						onChange: (e) => updateStyle({ [key]: e.target.value })
					})
				}, key))
			}) : null
		]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BibleView, {}) });
}
//#endregion
export { Page as component };
