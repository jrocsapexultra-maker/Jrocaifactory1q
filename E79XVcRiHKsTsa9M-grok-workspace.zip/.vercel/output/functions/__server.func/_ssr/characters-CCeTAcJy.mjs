import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useFactory, n as StudioShell, t as Button } from "./shell-DIXOIZBR.mjs";
import { n as Input, r as Textarea, t as Field } from "./field-C0C5rtLF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/characters-CCeTAcJy.js
var import_jsx_runtime = require_jsx_runtime();
function CharactersView() {
	const universe = useFactory((s) => s.universe);
	const selected = useFactory((s) => s.selectedCharacterId);
	const selectCharacter = useFactory((s) => s.selectCharacter);
	const upsertCharacter = useFactory((s) => s.upsertCharacter);
	const char = universe.characters.find((c) => c.id === selected) ?? universe.characters[0];
	function patch(p) {
		if (!char) return;
		upsertCharacter({
			...char,
			...p
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[220px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "grid h-fit gap-2",
			children: [universe.characters.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => selectCharacter(c.id),
				className: `rounded-md border px-3 py-3 text-left ${c.id === char?.id ? "border-accent bg-elevated" : "border-border bg-surface"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: c.role
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: c.name
				})]
			}, c.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => {
					const id = `char-${Date.now()}`;
					upsertCharacter({
						id,
						name: "New character",
						role: "Supporting",
						physical: "",
						face: "",
						body: "",
						hair: "",
						eyes: "",
						skin: "",
						costume: "",
						footwear: "",
						accessories: "",
						weapons: "",
						signature: "",
						palette: "",
						personality: "",
						voice: ""
					});
					selectCharacter(id);
				},
				children: "Add DNA"
			})]
		}), char ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-xl border border-border bg-surface md:grid md:grid-cols-[280px_1fr]",
				children: [char.frontRef ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: char.frontRef,
					alt: "",
					className: "h-80 w-full object-cover object-top md:h-full"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-48 items-center justify-center bg-elevated text-sm text-muted",
					children: "No front reference"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: char.name,
								onChange: (e) => patch({ name: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Role",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: char.role,
								onChange: (e) => patch({ role: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Signature features",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: char.signature,
								onChange: (e) => patch({ signature: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Color palette",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: char.palette,
								onChange: (e) => patch({ palette: e.target.value })
							})
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [
					["face", char.face],
					["body", char.body],
					["hair", char.hair],
					["eyes", char.eyes],
					["skin", char.skin],
					["physical", char.physical],
					["costume", char.costume],
					["footwear", char.footwear],
					["accessories", char.accessories],
					["weapons", char.weapons],
					["personality", char.personality],
					["voice", char.voice]
				].map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: key,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value,
						onChange: (e) => patch({ [key]: e.target.value })
					})
				}, key))
			})]
		}) : null]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CharactersView, {}) });
}
//#endregion
export { Page as component };
