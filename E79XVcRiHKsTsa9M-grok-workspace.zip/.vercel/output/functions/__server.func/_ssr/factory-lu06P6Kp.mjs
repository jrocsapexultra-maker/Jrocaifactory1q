import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useFactory, n as StudioShell, t as Button } from "./shell-DIXOIZBR.mjs";
import { t as Badge } from "./badge-Bxwz08H4.mjs";
import { t as Meter } from "./progress-P77548kW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/factory-lu06P6Kp.js
var import_jsx_runtime = require_jsx_runtime();
function FactoryView() {
	const universe = useFactory((s) => s.universe);
	const imageModel = useFactory((s) => s.imageModel);
	const textModel = useFactory((s) => s.textModel);
	const setModels = useFactory((s) => s.setModels);
	const patchJob = useFactory((s) => s.patchJob);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl tracking-tight",
				children: "Art Factory"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Free multi-model router. No API keys. Pollinations Flux and Turbo."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 rounded-xl border border-border bg-surface p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Model router"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wide text-muted",
								children: "Image"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: ["flux", "turbo"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: imageModel === m ? "primary" : "outline",
									onClick: () => setModels(m, textModel),
									children: m
								}, m))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-subtle",
								children: "Flux for finished panels. Turbo for storyboard drafts."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wide text-muted",
								children: "Story / Director"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: ["openai", "openai-fast"].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: textModel === m ? "primary" : "outline",
									onClick: () => setModels(imageModel, m),
									children: m
								}, m))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-subtle",
								children: "Free chat models via Pollinations. No paid keys."
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Production queue"
				}), universe.jobs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Queue is empty."
				}) : universe.jobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "grid gap-3 rounded-xl border border-border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: job.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: job.status === "done" ? "ok" : job.status === "failed" ? "bad" : job.status === "running" ? "ink" : "muted",
								children: job.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: job.task,
							value: job.progress
						}),
						job.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-bad",
							children: job.error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								job.status === "running" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => patchJob(job.id, { status: "paused" }),
									children: "Pause"
								}) : null,
								job.status === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => patchJob(job.id, { status: "running" }),
									children: "Resume"
								}) : null,
								job.status === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => patchJob(job.id, {
										status: "queued",
										error: void 0
									}),
									children: "Retry"
								}) : null
							]
						})
					]
				}, job.id))]
			})
		]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FactoryView, {}) });
}
//#endregion
export { Page as component };
