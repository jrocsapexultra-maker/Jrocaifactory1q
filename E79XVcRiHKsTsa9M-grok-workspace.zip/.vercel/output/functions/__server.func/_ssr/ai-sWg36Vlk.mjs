import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-sWg36Vlk.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var TEXT_URL = "https://text.pollinations.ai/openai";
var IMAGE_BASE = "https://image.pollinations.ai/prompt";
function buildFreeImageUrl(opts) {
	return `${IMAGE_BASE}/${encodeURIComponent(opts.prompt.slice(0, 1400))}?width=${opts.width ?? 1024}&height=${opts.height ?? 1024}&nologo=true&enhance=true&model=${opts.model ?? "flux"}&seed=${opts.seed ?? Math.floor(Math.random() * 1e6)}`;
}
async function freeChat(opts) {
	const res = await fetch(TEXT_URL, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			model: opts.model ?? "openai",
			messages: [{
				role: "system",
				content: opts.system
			}, {
				role: "user",
				content: opts.user
			}],
			seed: Math.floor(Math.random() * 1e4)
		})
	});
	if (!res.ok) {
		const fallback = await fetch(`https://text.pollinations.ai/${encodeURIComponent(`${opts.system}\n\n${opts.user}`)}?model=${opts.model ?? "openai"}`);
		if (!fallback.ok) return {
			ok: false,
			error: `Free model error ${res.status}`
		};
		return {
			ok: true,
			text: await fallback.text()
		};
	}
	const body = await res.json();
	const text = body.choices?.[0]?.message?.content ?? body.content ?? "";
	if (!text) return {
		ok: false,
		error: "Empty response from free model"
	};
	return {
		ok: true,
		text
	};
}
var listFreeModels_createServerFn_handler = createServerRpc({
	id: "0ce905c1e3b05b2a61df90187627839293ba8167be65a3c53158ab6e8600b9a8",
	name: "listFreeModels",
	filename: "src/lib/comic/ai.ts"
}, (opts) => listFreeModels.__executeServer(opts));
var listFreeModels = createServerFn({ method: "POST" }).handler(listFreeModels_createServerFn_handler, async () => {
	return {
		image: [{
			id: "flux",
			label: "Flux (Pollinations)",
			cost: "Free",
			bestFor: "Comic panels, characters"
		}, {
			id: "turbo",
			label: "Turbo (Pollinations)",
			cost: "Free",
			bestFor: "Fast drafts"
		}],
		text: [{
			id: "openai",
			label: "OpenAI via Pollinations",
			cost: "Free",
			bestFor: "Director / story"
		}, {
			id: "openai-fast",
			label: "OpenAI Fast",
			cost: "Free",
			bestFor: "Quick rewrites"
		}],
		router: ["pollinations-flux", "pollinations-turbo"]
	};
});
var askDirector_createServerFn_handler = createServerRpc({
	id: "972a4f78de945f3a266bdc8fb7d0d569740f21f4ed8cfc0d724510d7eaf557be",
	name: "askDirector",
	filename: "src/lib/comic/ai.ts"
}, (opts) => askDirector.__executeServer(opts));
var askDirector = createServerFn({ method: "POST" }).validator((input) => input).handler(askDirector_createServerFn_handler, async ({ data }) => {
	const result = await freeChat({
		model: data.model ?? "openai",
		system: "You are the Comic Director for WATCHERS, a rain-soaked western comic. Reply with JSON only, no markdown. Shape: { pageType, script, panels: [{ number, shot, camera, action, description, dialogue, speaker, caption, sfx }] }. 1-6 panels. Shots: establishing|wide|full|medium|close|extreme-close|over-shoulder|insert|bird|worm.",
		user: `Page ${data.pageNumber} type ${data.pageType}. Brief:\n${data.brief}`
	});
	if (!result.ok) return result;
	const text = result.text;
	const jsonStart = text.indexOf("{");
	const jsonEnd = text.lastIndexOf("}");
	if (jsonStart < 0 || jsonEnd < 0) return {
		ok: false,
		error: "Director returned no JSON"
	};
	try {
		return {
			ok: true,
			plan: JSON.parse(text.slice(jsonStart, jsonEnd + 1)),
			model: data.model ?? "openai"
		};
	} catch {
		return {
			ok: false,
			error: "Could not parse director JSON"
		};
	}
});
var writeStory_createServerFn_handler = createServerRpc({
	id: "82494191168a1515d116d4cc45d5ce9e93c8591bea0dac18a53d5683bc62a931",
	name: "writeStory",
	filename: "src/lib/comic/ai.ts"
}, (opts) => writeStory.__executeServer(opts));
var writeStory = createServerFn({ method: "POST" }).validator((input) => input).handler(writeStory_createServerFn_handler, async ({ data }) => {
	const result = await freeChat({
		model: data.model ?? "openai",
		system: "You are the story editor for WATCHERS. Write tight comic-script prose. No markdown headings. Stay inside the bible.",
		user: `BIBLE:\n${data.bible}\n\nCURRENT STORY:\n${data.current}\n\nINSTRUCTION:\n${data.instruction}`
	});
	if (!result.ok) return result;
	return {
		ok: true,
		text: result.text,
		model: data.model ?? "openai"
	};
});
var generatePanelArt_createServerFn_handler = createServerRpc({
	id: "ace94afe6fabf4cbae61a26f10d9e9364114c6169bf936135a3c04e242c3219c",
	name: "generatePanelArt",
	filename: "src/lib/comic/ai.ts"
}, (opts) => generatePanelArt.__executeServer(opts));
var generatePanelArt = createServerFn({ method: "POST" }).validator((input) => input).handler(generatePanelArt_createServerFn_handler, async ({ data }) => {
	const seed = data.seed ?? Math.floor(Math.random() * 1e6);
	const model = data.model ?? "flux";
	const url = buildFreeImageUrl({
		prompt: data.prompt,
		model,
		width: data.width,
		height: data.height,
		seed
	});
	try {
		const res = await fetch(url, { method: "GET" });
		if (!res.ok) return {
			ok: false,
			error: `Free image model ${res.status}`
		};
	} catch {}
	return {
		ok: true,
		url,
		model,
		seed
	};
});
//#endregion
export { askDirector_createServerFn_handler, generatePanelArt_createServerFn_handler, listFreeModels_createServerFn_handler, writeStory_createServerFn_handler };
