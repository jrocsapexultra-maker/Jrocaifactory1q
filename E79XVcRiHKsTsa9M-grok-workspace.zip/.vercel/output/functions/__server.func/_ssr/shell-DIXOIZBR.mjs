import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { f as useRouterState, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ShieldCheck, c as LayoutGrid, d as Download, f as Camera, l as GitBranch, n as Users, o as Menu, p as BookOpen, r as Type, s as Map, t as X, u as Factory } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-DIXOIZBR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-sm font-medium transition-opacity duration-150 disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			ghost: "text-fg hover:bg-elevated",
			outline: "border border-border text-fg hover:bg-elevated",
			subtle: "bg-elevated text-fg hover:opacity-90"
		},
		size: {
			sm: "h-9 px-3 text-sm",
			md: "h-11 px-4 text-sm",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var nid = (prefix, n) => `${prefix}-${String(n).padStart(2, "0")}`;
var WATCHERS = {
	id: "watchers",
	name: "WATCHERS",
	bible: {
		title: "WATCHERS",
		logline: "A banned civic sentinel returns to a drowned industrial city to stop the people who built him.",
		premise: "Sector 7 was sold as a smart-district. It became a weather-controlled prison. The Watcher was a municipal asset — a man rebuilt as a sensor platform — until he walked off the grid. Volume 01 is the night he comes home in the rain.",
		rules: [
			"No magic. Tech may look occult; it is always hardware.",
			"Rain never stops in Sector 7. If a scene is dry, it is indoors or a flashback.",
			"The Watcher does not kill on-panel in Volume 01.",
			"Nyx never shares her real name.",
			"Commissioner Reed always knows more than he says."
		],
		factions: [
			{
				name: "Civic Watch",
				note: "Municipal enforcement. Officially decommissioned."
			},
			{
				name: "Spire Board",
				note: "Owns the weather net and the cameras."
			},
			{
				name: "Ward 9",
				note: "Unlicensed medics under the rail yards."
			}
		],
		timeline: [
			{
				year: "Y-12",
				event: "Sector 7 weather net goes live."
			},
			{
				year: "Y-7",
				event: "Watcher program authorized in secret."
			},
			{
				year: "Y-1",
				event: "Watcher goes dark after the Spire fire."
			},
			{
				year: "Y-0",
				event: "Volume 01 — return night."
			}
		]
	},
	story: "A blackout hits Sector 7. Reed calls in a ghost. The Watcher arrives already injured. Nyx is hunting the same target for different reasons. By page 12 they have a name, a wound, and a war they cannot postpone.",
	style: {
		name: "Ink Storm",
		line: "Heavy western-comic ink. Thick blacks, sparse hatching, no screentone soup.",
		color: "Limited: black, steel, electric blue, bone. Crimson only for Nyx and blood.",
		lighting: "Practical neon, lightning, fluorescents. Faces half in shadow.",
		camera: "Low angles for Watcher. Tight inserts for hardware. Rain always in the frame.",
		lettering: "Bold condensed balloons. Captions in small caps. SFX as ink, not fonts-as-effects.",
		references: "Miller rain, Toth silhouettes, 90s Vertigo night city — not anime, not painterly."
	},
	characters: [
		{
			id: "watcher",
			name: "The Watcher",
			role: "Protagonist",
			physical: "Tall, athletic, broad-shouldered, slightly too still.",
			face: "Sharp jaw, scar across right cheek, often half-masked.",
			body: "Long-limbed, military posture, left shoulder held stiff.",
			hair: "Short black hair with a silver streak at the temple.",
			eyes: "Dark right eye; left eye a glowing cyan implant.",
			skin: "Olive, rain-slick, faint implant seams at the temple.",
			costume: "Black tactical suit, cracked left shoulder plating (Damaged V2).",
			footwear: "Silent black boots, worn soles.",
			accessories: "Throat mic, rain cloak when moving rooftops.",
			weapons: "Plasma rifle, currently holstered on the back.",
			signature: "Glowing cyan left eye, silver streak, cracked V2 pauldron.",
			palette: "Black, silver, electric blue.",
			personality: "Spare speech. Measures rooms before entering them.",
			voice: "Low, unhurried, almost polite.",
			frontRef: "/universe/watcher.jpg"
		},
		{
			id: "nyx",
			name: "Nyx",
			role: "Antagonist / uneasy ally",
			physical: "Lean, fast, a head shorter than Watcher.",
			face: "Sharp cheekbones, unreadable mouth.",
			body: "Dancer's balance, knife-fighter shoulders.",
			hair: "Undercut, dark, rain-plastered.",
			eyes: "Gold iris, no glow.",
			skin: "Fair, a nick on the left brow.",
			costume: "Black bodysuit, crimson sash at the waist.",
			footwear: "Soft-soled climb shoes.",
			accessories: "Wire garrote coiled at the wrist.",
			weapons: "Twin knives, always drawn last.",
			signature: "Crimson sash, gold eyes, undercut.",
			palette: "Black, crimson, pale gold.",
			personality: "Wry. Never explains the job until the body is down.",
			voice: "Dry, slightly amused.",
			frontRef: "/universe/nyx.jpg"
		},
		{
			id: "reed",
			name: "Commissioner Reed",
			role: "Fixer",
			physical: "Heavy, slower than he used to be.",
			face: "Weathered, grey stubble, tired eyes.",
			body: "Barrel chest, bad knee.",
			hair: "Iron grey, thinning.",
			eyes: "Pale, always squinting in rain.",
			skin: "Flushed, smoker.",
			costume: "Rain-soaked trench over a rumpled suit.",
			footwear: "City oxfords, ruined.",
			accessories: "Badge he no longer flashes, cheap lighter.",
			weapons: "Service pistol, rarely drawn.",
			signature: "Trench, cigarette, the look of a man who already lost.",
			palette: "Umber, steel, wet concrete.",
			personality: "Cynical caretaker. Speaks in bargains.",
			voice: "Raspy, municipal.",
			frontRef: "/universe/reed.jpg"
		}
	],
	locations: [
		{
			id: "sector7",
			name: "Sector 7",
			type: "District",
			description: "Industrial smart-grid sold as a future and run as a cage.",
			atmosphere: "Perpetual rain, neon on rust, empty platforms.",
			lighting: "Sodium, cyan signage, lightning.",
			palette: "Black, rust, electric blue.",
			landmarks: "Rail spine, weather towers, drowned underpass.",
			image: "/universe/sector7.jpg"
		},
		{
			id: "spire",
			name: "The Spire",
			type: "HQ",
			description: "Brutalist glass tower that owns the cameras and the weather.",
			atmosphere: "Quiet, expensive, air-conditioned lie.",
			lighting: "Cold interior whites, searchlights outside.",
			palette: "Glass, steel, cyan.",
			landmarks: "Board floor, server well, roof helipad.",
			image: "/universe/sector7.jpg"
		},
		{
			id: "ward",
			name: "Medical Ward 9",
			type: "Safehouse",
			description: "Unlicensed clinic under the rail, fluorescent and honest.",
			atmosphere: "Bleach, rain on cracked glass, whispered triage.",
			lighting: "Flicker fluorescents, green spill.",
			palette: "Sickly green, steel, bone.",
			landmarks: "Three beds, a locked fridge, a radio that never works.",
			image: "/universe/medical.jpg"
		}
	],
	props: [
		{
			id: "rifle",
			name: "Plasma Rifle",
			owner: "watcher",
			description: "Civic-issue, housing cracked, still hot to the touch.",
			state: "Holstered, charged 40%.",
			image: "/universe/cover.jpg"
		},
		{
			id: "badge",
			name: "Reed's Badge",
			owner: "reed",
			description: "Tarnished. He keeps it in the coat, not on it.",
			state: "Concealed."
		},
		{
			id: "sash",
			name: "Crimson Sash",
			owner: "nyx",
			description: "Silk that should not survive this weather. It does.",
			state: "Worn."
		}
	],
	volume: {
		id: "vol-01",
		title: "Return Night",
		issue: "VOLUME 01",
		pageCount: 12,
		chapters: [
			{
				id: "ch-1",
				title: "Blackout",
				synopsis: "Reed calls a ghost. The rain answers first.",
				pageIds: [
					"p-01",
					"p-02",
					"p-03",
					"p-04"
				]
			},
			{
				id: "ch-2",
				title: "Sash",
				synopsis: "Nyx is already on the roof.",
				pageIds: [
					"p-05",
					"p-06",
					"p-07",
					"p-08"
				]
			},
			{
				id: "ch-3",
				title: "Ward",
				synopsis: "A name, a wound, a war.",
				pageIds: [
					"p-09",
					"p-10",
					"p-11",
					"p-12"
				]
			}
		]
	},
	pages: [
		{
			id: "p-01",
			number: 1,
			type: "COVER",
			title: "Return Night",
			script: "Cover. Watcher leaping debris, rain, lightning. No copy except logo later.",
			layout: "full-bleed",
			status: "approved",
			finalImage: "/universe/cover.jpg",
			panels: [{
				id: "p-01-a",
				number: 1,
				shot: "worm",
				camera: "low, looking up through rain",
				action: "Watcher leaps wreckage",
				description: "Full-bleed cover of Watcher in Damaged V2 suit leaping over debris in Sector 7 rain.",
				dialogue: "",
				caption: "",
				sfx: "",
				prompt: "",
				negative: "text, watermark, extra limbs",
				selectedGenerationId: "g-cover",
				balloonX: 70,
				balloonY: 12
			}],
			qc: {
				art: true,
				character: true,
				continuity: true,
				lettering: true,
				bleed: true,
				flags: []
			}
		},
		page(2, "STANDARD", "Call", "approved", "/universe/sector7.jpg", "Reed on a pay-phone under a dead camera."),
		page(3, "ACTION", "Arrival", "approved", "/universe/cover.jpg", "Watcher drops from a weather tower."),
		page(4, "DIALOGUE", "Terms", "approved", "/universe/reed.jpg", "Reed and Watcher in the underpass."),
		page(5, "ACTION", "Sash", "qc", "/universe/nyx.jpg", "Nyx intercepts on the rail spine. QC: costume check."),
		page(6, "STANDARD", "Knives", "generating", void 0, "Close work on the roof. Art in queue."),
		page(7, "SPLASH", "Lightning", "approved", "/universe/sector7.jpg", "Both silhouettes against a strike."),
		page(8, "DIALOGUE", "Names", "review", "/universe/nyx.jpg", "They trade partial truths."),
		page(9, "STANDARD", "Ward", "approved", "/universe/medical.jpg", "Watcher sits for stitches."),
		page(10, "DIALOGUE", "The Board", "storyboard", void 0, "Reed names the Spire."),
		page(11, "ACTION", "Out", "empty", void 0, "They leave the ward into rain."),
		page(12, "FINAL", "Look Up", "empty", void 0, "The Spire lights the clouds. End of volume.")
	],
	events: [
		{
			id: "e1",
			pageNumber: 1,
			characterId: "watcher",
			field: "costume",
			value: "Damaged V2 — cracked left pauldron"
		},
		{
			id: "e2",
			pageNumber: 1,
			characterId: "watcher",
			field: "weapons",
			value: "Plasma rifle holstered"
		},
		{
			id: "e3",
			pageNumber: 1,
			field: "location",
			value: "Sector 7 industrial street"
		},
		{
			id: "e4",
			pageNumber: 1,
			field: "weather",
			value: "Heavy rain"
		},
		{
			id: "e5",
			pageNumber: 1,
			field: "timeOfDay",
			value: "02:17"
		},
		{
			id: "e6",
			pageNumber: 3,
			characterId: "watcher",
			field: "injuries",
			value: "Cut on left forearm"
		},
		{
			id: "e7",
			pageNumber: 5,
			characterId: "nyx",
			field: "costume",
			value: "Black bodysuit, crimson sash"
		},
		{
			id: "e8",
			pageNumber: 5,
			field: "location",
			value: "Rail spine rooftops"
		},
		{
			id: "e9",
			pageNumber: 9,
			field: "location",
			value: "Medical Ward 9"
		},
		{
			id: "e10",
			pageNumber: 9,
			characterId: "watcher",
			field: "costume",
			value: "Suit open at the shoulder, plating off"
		},
		{
			id: "e11",
			pageNumber: 12,
			field: "location",
			value: "View of The Spire from Ward alley"
		}
	],
	generations: [{
		id: "g-cover",
		panelId: "p-01-a",
		pageId: "p-01",
		model: "seed",
		prompt: "cover",
		image: "/universe/cover.jpg",
		status: "done",
		createdAt: "2026-09-24T00:00:00Z",
		note: "v3 — selected"
	}],
	jobs: [{
		id: "j-1",
		label: "Page 06 / Panel 02",
		task: "comic_panel",
		status: "running",
		progress: 62,
		pageId: "p-06",
		createdAt: "2026-09-24T06:40:00Z"
	}, {
		id: "j-2",
		label: "Page 10 storyboard",
		task: "storyboard",
		status: "queued",
		progress: 0,
		pageId: "p-10",
		createdAt: "2026-09-24T06:41:00Z"
	}]
};
function page(number, type, title, status, image, script) {
	const id = nid("p", number);
	const panelCount = type === "COVER" || type === "SPLASH" || type === "FINAL" ? 1 : type === "ACTION" ? 5 : 4;
	const panels = Array.from({ length: panelCount }, (_, i) => ({
		id: `${id}-${i + 1}`,
		number: i + 1,
		shot: i === 0 ? "wide" : i === panelCount - 1 ? "close" : "medium",
		camera: i % 2 === 0 ? "eye level" : "low",
		action: script,
		description: script,
		dialogue: i === panelCount - 1 && type === "DIALOGUE" ? "—" : "",
		caption: i === 0 ? script : "",
		sfx: type === "ACTION" && i === 1 ? "KRACK" : "",
		prompt: "",
		negative: "text, watermark, extra fingers, deformed anatomy",
		selectedGenerationId: image && i === 0 ? `seed-${id}` : void 0,
		balloonX: 18 + i * 12,
		balloonY: 14 + i % 2 * 20
	}));
	return {
		id,
		number,
		type,
		title,
		script,
		layout: type === "SPLASH" || type === "COVER" ? "full-bleed" : `${panelCount}-grid`,
		status,
		finalImage: image,
		panels,
		qc: {
			art: status === "approved" || status === "published",
			character: status === "approved" || status === "published",
			continuity: status !== "qc",
			lettering: status === "approved" || status === "published",
			bleed: true,
			flags: status === "qc" ? ["Nyx sash color drift on panel 3"] : []
		}
	};
}
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}
var useFactory = create()(persist((set, get) => ({
	universe: WATCHERS,
	selectedPageId: "p-05",
	selectedCharacterId: "watcher",
	imageModel: "flux",
	textModel: "openai",
	resetUniverse: () => set({
		universe: WATCHERS,
		selectedPageId: "p-05",
		selectedCharacterId: "watcher",
		imageModel: "flux",
		textModel: "openai"
	}),
	setModels: (imageModel, textModel) => set({
		imageModel,
		textModel
	}),
	setStory: (story) => set({ universe: {
		...get().universe,
		story
	} }),
	updateBible: (patch) => set({ universe: {
		...get().universe,
		bible: {
			...get().universe.bible,
			...patch
		}
	} }),
	updateStyle: (patch) => set({ universe: {
		...get().universe,
		style: {
			...get().universe.style,
			...patch
		}
	} }),
	upsertCharacter: (c) => {
		const chars = get().universe.characters;
		const next = chars.findIndex((x) => x.id === c.id) >= 0 ? chars.map((x) => x.id === c.id ? c : x) : [...chars, c];
		set({ universe: {
			...get().universe,
			characters: next
		} });
	},
	upsertLocation: (l) => {
		const list = get().universe.locations;
		const next = list.findIndex((x) => x.id === l.id) >= 0 ? list.map((x) => x.id === l.id ? l : x) : [...list, l];
		set({ universe: {
			...get().universe,
			locations: next
		} });
	},
	upsertProp: (p) => {
		const list = get().universe.props;
		const next = list.findIndex((x) => x.id === p.id) >= 0 ? list.map((x) => x.id === p.id ? p : x) : [...list, p];
		set({ universe: {
			...get().universe,
			props: next
		} });
	},
	selectPage: (id) => set({ selectedPageId: id }),
	selectCharacter: (id) => set({ selectedCharacterId: id }),
	updatePage: (id, patch) => set({ universe: {
		...get().universe,
		pages: get().universe.pages.map((p) => p.id === id ? {
			...p,
			...patch
		} : p)
	} }),
	updatePanel: (pageId, panelId, patch) => set({ universe: {
		...get().universe,
		pages: get().universe.pages.map((p) => p.id === pageId ? {
			...p,
			panels: p.panels.map((n) => n.id === panelId ? {
				...n,
				...patch
			} : n)
		} : p)
	} }),
	addEvent: (e) => set({ universe: {
		...get().universe,
		events: [...get().universe.events, {
			...e,
			id: uid("ev")
		}]
	} }),
	applyDirectorPlan: (pageId, panels, type, script) => set({ universe: {
		...get().universe,
		pages: get().universe.pages.map((p) => p.id === pageId ? {
			...p,
			panels,
			type: type ?? p.type,
			script: script ?? p.script,
			status: p.status === "empty" ? "storyboard" : p.status,
			layout: `${panels.length}-grid`
		} : p)
	} }),
	addGeneration: (g) => set({ universe: {
		...get().universe,
		generations: [g, ...get().universe.generations]
	} }),
	selectGeneration: (pageId, panelId, genId) => {
		const gen = get().universe.generations.find((g) => g.id === genId);
		set({ universe: {
			...get().universe,
			pages: get().universe.pages.map((p) => p.id === pageId ? {
				...p,
				panels: p.panels.map((n) => n.id === panelId ? {
					...n,
					selectedGenerationId: genId
				} : n),
				finalImage: gen?.image ?? p.finalImage,
				status: p.status === "generating" ? "review" : p.status
			} : p)
		} });
	},
	enqueueJob: (job) => {
		const id = uid("job");
		set({ universe: {
			...get().universe,
			jobs: [{
				...job,
				id,
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			}, ...get().universe.jobs]
		} });
		return id;
	},
	patchJob: (id, patch) => set({ universe: {
		...get().universe,
		jobs: get().universe.jobs.map((j) => j.id === id ? {
			...j,
			...patch
		} : j)
	} }),
	setPageStatus: (id, status) => set({ universe: {
		...get().universe,
		pages: get().universe.pages.map((p) => p.id === id ? {
			...p,
			status
		} : p)
	} }),
	toggleQc: (pageId, key) => {
		if (key === "flags") return;
		set({ universe: {
			...get().universe,
			pages: get().universe.pages.map((p) => p.id === pageId ? {
				...p,
				qc: {
					...p.qc,
					[key]: !p.qc[key]
				}
			} : p)
		} });
	}
}), {
	name: "jrocai-factory-v2",
	skipHydration: true
}));
function pipelinePercents(u) {
	const n = u.pages.length || 1;
	return {
		story: u.story.trim() ? 100 : 40,
		board: Math.round(u.pages.filter((p) => p.status !== "empty").length / n * 100),
		art: Math.round(u.pages.filter((p) => [
			"review",
			"qc",
			"approved",
			"published",
			"generating"
		].includes(p.status)).length / n * 100),
		cont: Math.round(u.pages.filter((p) => p.qc.continuity).length / n * 100),
		letter: Math.round(u.pages.filter((p) => p.qc.lettering).length / n * 100),
		pub: Math.round(u.pages.filter((p) => p.status === "published" || p.status === "approved").length / n * 100)
	};
}
var NAV = [
	{
		to: "/",
		label: "Studio",
		icon: LayoutGrid
	},
	{
		to: "/bible",
		label: "Universe Bible",
		icon: BookOpen
	},
	{
		to: "/characters",
		label: "Character DNA",
		icon: Users
	},
	{
		to: "/world",
		label: "Locations / Props",
		icon: Map
	},
	{
		to: "/pages",
		label: "Pages",
		icon: Camera
	},
	{
		to: "/factory",
		label: "Art Factory",
		icon: Factory
	},
	{
		to: "/continuity",
		label: "Continuity",
		icon: GitBranch
	},
	{
		to: "/lettering",
		label: "Lettering",
		icon: Type
	},
	{
		to: "/qc",
		label: "Quality Control",
		icon: ShieldCheck
	},
	{
		to: "/publish",
		label: "Publish",
		icon: Download
	}
];
function StudioShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const universe = useFactory((s) => s.universe);
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		useFactory.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "no-print sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-bg px-4 md:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "md:hidden",
							onClick: () => setOpen(true),
							"aria-label": "Open menu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "flex items-baseline gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-lg tracking-tight",
								children: "JROCAI"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs uppercase tracking-[0.2em] text-muted",
								children: "Factory"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center gap-4 md:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs uppercase tracking-wide text-muted",
								children: "Project"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: universe.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "/"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs",
								children: universe.volume.issue
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-sm border border-border px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-ink",
						children: "Elite"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-[1600px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "no-print sticky top-14 hidden h-[calc(100dvh-3.5rem)] w-56 shrink-0 overflow-y-auto border-r border-border p-3 md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, { pathname })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "min-w-0 flex-1 p-4 md:p-8",
					children
				})]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "absolute inset-0 bg-bg/80",
					onClick: () => setOpen(false),
					"aria-label": "Close menu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-y-0 left-0 flex w-72 flex-col gap-2 border-r border-border bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg",
							children: "Menu"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							onClick: () => setOpen(false),
							"aria-label": "Close",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
						pathname,
						onNavigate: () => setOpen(false)
					})]
				})]
			}) : null
		]
	});
}
function Nav({ pathname, onNavigate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "grid gap-1",
		children: NAV.map((item) => {
			const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				onClick: onNavigate,
				className: cn("flex h-11 items-center gap-3 rounded-sm px-3 text-sm transition-colors duration-150", active ? "bg-elevated text-fg" : "text-muted hover:bg-elevated hover:text-fg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }), item.label]
			}, item.to);
		})
	});
}
//#endregion
export { useFactory as a, pipelinePercents as i, StudioShell as n, cn as r, Button as t };
