import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useFactory, n as StudioShell, t as Button } from "./shell-DIXOIZBR.mjs";
import { t as Badge } from "./badge-Bxwz08H4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qc-D6nlIkLl.js
var import_jsx_runtime = require_jsx_runtime();
var CHECKS = [
	"art",
	"character",
	"continuity",
	"lettering",
	"bleed"
];
function QcView() {
	const universe = useFactory((s) => s.universe);
	const toggleQc = useFactory((s) => s.toggleQc);
	const setPageStatus = useFactory((s) => s.setPageStatus);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl tracking-tight",
			children: "Review Board"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "A page is published only when every check is green."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3",
			children: universe.pages.map((page) => {
				const ready = CHECKS.every((k) => page.qc[k]);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "grid gap-3 rounded-xl border border-border bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-medium",
								children: [
									String(page.number).padStart(3, "0"),
									" ",
									page.title
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: ready ? "ok" : page.qc.flags.length ? "warn" : "muted",
								children: ready ? "ready" : page.qc.flags[0] || page.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: CHECKS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: page.qc[k] ? "primary" : "outline",
								onClick: () => toggleQc(page.id, k),
								children: [
									k,
									" ",
									page.qc[k] ? "yes" : "no"
								]
							}, k))
						}),
						ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => setPageStatus(page.id, "published"),
							children: "Publish page"
						}) : null
					]
				}, page.id);
			})
		})]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QcView, {}) });
}
//#endregion
export { Page as component };
