import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as cn } from "./shell-DIXOIZBR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-Bxwz08H4.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "muted", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-7 items-center rounded-sm border px-2 font-mono text-xs uppercase tracking-wide", {
			muted: "text-muted border-border",
			ok: "text-ok border-ok/40",
			warn: "text-warn border-warn/40",
			bad: "text-bad border-bad/40",
			ink: "text-ink border-ink/40"
		}[tone], className),
		...props
	});
}
//#endregion
export { Badge as t };
