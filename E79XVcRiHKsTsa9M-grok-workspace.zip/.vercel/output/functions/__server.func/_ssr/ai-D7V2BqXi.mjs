import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-D7V2BqXi.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
createServerFn({ method: "POST" }).handler(createSsrRpc("0ce905c1e3b05b2a61df90187627839293ba8167be65a3c53158ab6e8600b9a8"));
var askDirector = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("972a4f78de945f3a266bdc8fb7d0d569740f21f4ed8cfc0d724510d7eaf557be"));
var writeStory = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("82494191168a1515d116d4cc45d5ce9e93c8591bea0dac18a53d5683bc62a931"));
var generatePanelArt = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("ace94afe6fabf4cbae61a26f10d9e9364114c6169bf936135a3c04e242c3219c"));
//#endregion
export { generatePanelArt as n, writeStory as r, askDirector as t };
