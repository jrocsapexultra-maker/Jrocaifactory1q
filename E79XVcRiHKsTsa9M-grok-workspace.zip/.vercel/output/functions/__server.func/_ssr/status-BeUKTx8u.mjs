//#region node_modules/.nitro/vite/services/ssr/assets/status-BeUKTx8u.js
function statusTone(status) {
	switch (status) {
		case "approved":
		case "published": return "ok";
		case "qc":
		case "review": return "warn";
		case "generating": return "ink";
		default: return "muted";
	}
}
function statusMark(status) {
	switch (status) {
		case "approved":
		case "published": return "✓";
		case "qc": return "!";
		case "generating": return "●";
		case "review": return "R";
		case "storyboard": return "S";
		default: return "○";
	}
}
//#endregion
export { statusTone as n, statusMark as t };
