import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useFactory, n as StudioShell } from "./shell-DIXOIZBR.mjs";
import { t as Badge } from "./badge-Bxwz08H4.mjs";
import { n as statusTone } from "./status-BeUKTx8u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pages-DSVkvXCo.js
var import_jsx_runtime = require_jsx_runtime();
function PagesGrid() {
	const universe = useFactory((s) => s.universe);
	const selectPage = useFactory((s) => s.selectPage);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl tracking-tight",
			children: "Volume pages"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-muted",
			children: [
				universe.volume.title,
				" · ",
				universe.volume.pageCount,
				" pages · ",
				universe.pages.reduce((n, p) => n + p.panels.length, 0),
				" panels"
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
			children: universe.pages.map((page) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/pages/$pageId",
				params: { pageId: page.id },
				onClick: () => selectPage(page.id),
				className: "overflow-hidden rounded-xl border border-border bg-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-56 bg-elevated",
					children: [page.finalImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: page.finalImage,
						alt: "",
						className: "h-full w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-full items-center justify-center font-mono text-muted",
						children: page.layout
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute left-3 top-3 font-mono text-xs tabular-nums text-accent-fg bg-accent px-2 py-1 rounded-sm",
						children: String(page.number).padStart(3, "0")
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: page.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wide text-muted",
						children: page.type
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(page.status),
						children: page.status
					})]
				})]
			}, page.id))
		})]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PagesGrid, {}) });
}
//#endregion
export { Page as component };
