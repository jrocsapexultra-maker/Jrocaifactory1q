//#region node_modules/.nitro/vite/services/ssr/assets/continuity-D7MjaFUF.js
function emptyState() {
	return {
		costume: {},
		injuries: {},
		weapons: {},
		props: [],
		vehicles: [],
		location: "",
		weather: "",
		timeOfDay: "",
		damage: "",
		position: {}
	};
}
function buildContinuityState(events, pageNumber) {
	const state = emptyState();
	const applicable = events.filter((e) => e.pageNumber <= pageNumber).sort((a, b) => a.pageNumber - b.pageNumber);
	for (const e of applicable) switch (e.field) {
		case "costume":
			if (e.characterId) state.costume[e.characterId] = e.value;
			break;
		case "injuries":
			if (e.characterId) state.injuries[e.characterId] = e.value;
			break;
		case "weapons":
			if (e.characterId) state.weapons[e.characterId] = e.value;
			break;
		case "props":
			state.props = [.../* @__PURE__ */ new Set([...state.props, e.value])];
			break;
		case "vehicles":
			state.vehicles = [.../* @__PURE__ */ new Set([...state.vehicles, e.value])];
			break;
		case "location":
			state.location = e.value;
			break;
		case "weather":
			state.weather = e.value;
			break;
		case "timeOfDay":
			state.timeOfDay = e.value;
			break;
		case "damage":
			state.damage = e.value;
			break;
		case "position": if (e.characterId) state.position[e.characterId] = e.value;
	}
	return state;
}
//#endregion
export { buildContinuityState as t };
