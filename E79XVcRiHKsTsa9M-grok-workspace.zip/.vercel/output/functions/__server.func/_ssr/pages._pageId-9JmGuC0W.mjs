import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { b as useParams, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useFactory, n as StudioShell, t as Button } from "./shell-DIXOIZBR.mjs";
import { r as Textarea, t as Field } from "./field-C0C5rtLF.mjs";
import { n as generatePanelArt, t as askDirector } from "./ai-D7V2BqXi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as buildContinuityState } from "./continuity-D7MjaFUF.mjs";
import { t as Badge } from "./badge-Bxwz08H4.mjs";
import { n as statusTone } from "./status-BeUKTx8u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pages._pageId-9JmGuC0W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function characterPrompt(c, costumeOverride) {
	return [
		c.name,
		c.face,
		c.body,
		`hair: ${c.hair}`,
		`eyes: ${c.eyes}`,
		`wearing: ${costumeOverride ?? c.costume}`,
		c.footwear,
		c.accessories,
		`signature: ${c.signature}`,
		`palette: ${c.palette}`
	].filter(Boolean).join(", ");
}
function buildPanelPrompt(opts) {
	const { panel, page, style, characters, state } = opts;
	const dna = characters.map((c) => characterPrompt(c, state.costume[c.id])).join(" | ");
	const cont = [
		state.location && `location: ${state.location}`,
		state.weather && `weather: ${state.weather}`,
		state.timeOfDay && `time: ${state.timeOfDay}`,
		state.damage && `environment: ${state.damage}`,
		...Object.entries(state.injuries).map(([id, v]) => {
			return `${characters.find((c) => c.id === id)?.name ?? id} injury: ${v}`;
		}),
		...Object.entries(state.weapons).map(([id, v]) => {
			return `${characters.find((c) => c.id === id)?.name ?? id} weapon: ${v}`;
		})
	].filter(Boolean).join("; ");
	return [
		"western comic book panel, print coloring, bold black ink, high contrast",
		style.line,
		style.color,
		style.lighting,
		`page type ${page.type}, shot ${panel.shot}, camera ${panel.camera}`,
		panel.action,
		panel.description,
		dna,
		cont,
		"no captions, no speech balloons, no watermark, no extra limbs"
	].filter(Boolean).join(". ");
}
function PageEditor() {
	const { pageId } = useParams({ from: "/pages/$pageId" });
	const universe = useFactory((s) => s.universe);
	const imageModel = useFactory((s) => s.imageModel);
	const textModel = useFactory((s) => s.textModel);
	const applyDirectorPlan = useFactory((s) => s.applyDirectorPlan);
	const updatePanel = useFactory((s) => s.updatePanel);
	const addGeneration = useFactory((s) => s.addGeneration);
	const selectGeneration = useFactory((s) => s.selectGeneration);
	const enqueueJob = useFactory((s) => s.enqueueJob);
	const patchJob = useFactory((s) => s.patchJob);
	const setPageStatus = useFactory((s) => s.setPageStatus);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const page = universe.pages.find((p) => p.id === pageId);
	if (!page) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Page not found." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/pages",
			className: "text-ink underline",
			children: "Back to pages"
		})]
	});
	const state = buildContinuityState(universe.events, page.number);
	async function runDirector() {
		if (!page) return;
		setBusy("director");
		const res = await askDirector({ data: {
			brief: `${universe.story}\n\nPage brief: ${page.script}\nStyle: ${universe.style.line} ${universe.style.color}\nContinuity location ${state.location}, weather ${state.weather}.`,
			pageNumber: page.number,
			pageType: page.type,
			model: textModel
		} });
		setBusy(null);
		if (!res.ok) {
			toast.error(res.error);
			return;
		}
		const panels = (res.plan.panels ?? []).slice(0, 6).map((p, i) => ({
			id: `${page.id}-${i + 1}`,
			number: i + 1,
			shot: p.shot || "medium",
			camera: p.camera,
			action: p.action,
			description: p.description,
			dialogue: p.dialogue ?? "",
			speaker: p.speaker,
			caption: p.caption ?? "",
			sfx: p.sfx ?? "",
			prompt: "",
			negative: "text, watermark, extra fingers, deformed anatomy",
			balloonX: 16 + i % 3 * 22,
			balloonY: 12 + i % 2 * 28
		}));
		applyDirectorPlan(page.id, panels, page.type, res.plan.script ?? page.script);
		toast.success(`Director planned ${panels.length} panels with ${res.model}`);
	}
	async function generatePanel(panel) {
		if (!page) return;
		const prompt = buildPanelPrompt({
			panel,
			page,
			style: universe.style,
			characters: universe.characters,
			state
		});
		const jobId = enqueueJob({
			label: `Page ${String(page.number).padStart(3, "0")} / Panel ${panel.number}`,
			task: "comic_panel",
			status: "running",
			progress: 15,
			pageId: page.id,
			panelId: panel.id
		});
		setPageStatus(page.id, "generating");
		setBusy(panel.id);
		const seed = Math.floor(Math.random() * 1e6);
		const res = await generatePanelArt({ data: {
			prompt,
			model: imageModel,
			width: 1024,
			height: page.type === "COVER" || page.type === "SPLASH" ? 1536 : 1024,
			seed
		} });
		setBusy(null);
		if (!res.ok) {
			patchJob(jobId, {
				status: "failed",
				error: res.error,
				progress: 0
			});
			toast.error(res.error);
			return;
		}
		const genId = `g-${panel.id}-${seed}`;
		addGeneration({
			id: genId,
			panelId: panel.id,
			pageId: page.id,
			model: `pollinations-${res.model}`,
			prompt,
			image: res.url,
			seed: res.seed,
			status: "done",
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			note: "v1"
		});
		selectGeneration(page.id, panel.id, genId);
		updatePanel(page.id, panel.id, { prompt });
		patchJob(jobId, {
			status: "done",
			progress: 100
		});
		toast.success(`Panel ${panel.number} via ${res.model}`);
	}
	const gens = universe.generations.filter((g) => g.pageId === page.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs text-muted",
					children: [
						"PAGE ",
						String(page.number).padStart(3, "0"),
						" · ",
						page.type
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: page.title
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: statusTone(page.status),
					children: page.status
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 rounded-xl border border-border bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: page.script
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-subtle",
						children: [
							"Continuity · ",
							state.location || "unknown",
							" · ",
							state.weather || "—",
							" · ",
							state.timeOfDay || "—"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: runDirector,
							disabled: busy === "director",
							children: busy === "director" ? "Directing…" : "Comic Director (free)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => page.panels.forEach((p) => void generatePanel(p)),
							disabled: !!busy,
							children: "Generate all panels"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: page.panels.map((panel) => {
					const selected = gens.find((g) => g.id === panel.selectedGenerationId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "overflow-hidden rounded-xl border border-border bg-surface",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-[4/3] bg-elevated",
							children: [
								selected?.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: selected.image,
									alt: "",
									className: "h-full w-full object-cover"
								}) : page.finalImage && panel.number === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: page.finalImage,
									alt: "",
									className: "h-full w-full object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex h-full flex-col items-center justify-center gap-1 p-4 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs text-muted",
										children: [
											panel.shot,
											" · ",
											panel.camera
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-subtle",
										children: panel.action
									})]
								}),
								panel.dialogue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute max-w-[70%] rounded-md bg-accent px-2 py-1 text-xs text-accent-fg",
									style: {
										left: `${panel.balloonX}%`,
										top: `${panel.balloonY}%`
									},
									children: panel.dialogue
								}) : null,
								panel.sfx ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute bottom-3 right-3 font-display text-lg text-ink",
									children: panel.sfx
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-mono text-xs",
										children: ["PANEL ", String(panel.number).padStart(2, "0")]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: () => generatePanel(panel),
										disabled: busy === panel.id,
										children: busy === panel.id ? "Flux…" : `Generate · ${imageModel}`
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Action",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										value: panel.action,
										onChange: (e) => updatePanel(page.id, panel.id, { action: e.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Dialogue",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										value: panel.dialogue,
										onChange: (e) => updatePanel(page.id, panel.id, { dialogue: e.target.value })
									})
								})
							]
						})]
					}, panel.id);
				})
			})
		]
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageEditor, {}) });
}
//#endregion
export { Page as component };
