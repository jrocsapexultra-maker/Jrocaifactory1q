import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { ContinuityView } from "@/components/studio/continuity";

export const Route = createFileRoute("/continuity")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <ContinuityView />
    </StudioShell>
  );
}
