import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { FactoryView } from "@/components/studio/factory";

export const Route = createFileRoute("/factory")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <FactoryView />
    </StudioShell>
  );
}
