import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { QcView } from "@/components/studio/qc";

export const Route = createFileRoute("/qc")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <QcView />
    </StudioShell>
  );
}
