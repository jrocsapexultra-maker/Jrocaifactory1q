import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { WorldView } from "@/components/studio/world";

export const Route = createFileRoute("/world")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <WorldView />
    </StudioShell>
  );
}
