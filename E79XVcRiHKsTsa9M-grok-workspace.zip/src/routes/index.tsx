import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { Dashboard } from "@/components/studio/dashboard";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <StudioShell>
      <Dashboard />
    </StudioShell>
  );
}
