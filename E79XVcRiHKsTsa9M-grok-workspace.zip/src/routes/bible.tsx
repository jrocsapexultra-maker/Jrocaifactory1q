import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { BibleView } from "@/components/studio/bible";

export const Route = createFileRoute("/bible")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <BibleView />
    </StudioShell>
  );
}
