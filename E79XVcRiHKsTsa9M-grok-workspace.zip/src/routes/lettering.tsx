import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { LetteringView } from "@/components/studio/lettering";

export const Route = createFileRoute("/lettering")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <LetteringView />
    </StudioShell>
  );
}
