import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { PagesGrid } from "@/components/studio/pages-grid";

export const Route = createFileRoute("/pages")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <PagesGrid />
    </StudioShell>
  );
}
