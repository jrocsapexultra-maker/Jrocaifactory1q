import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { PublishView } from "@/components/studio/publish";

export const Route = createFileRoute("/publish")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <PublishView />
    </StudioShell>
  );
}
