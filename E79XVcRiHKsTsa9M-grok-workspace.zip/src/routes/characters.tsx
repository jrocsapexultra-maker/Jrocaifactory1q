import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { CharactersView } from "@/components/studio/characters";

export const Route = createFileRoute("/characters")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <CharactersView />
    </StudioShell>
  );
}
