import { createFileRoute } from "@tanstack/react-router";
import { StudioShell } from "@/components/studio/shell";
import { PageEditor } from "@/components/studio/page-editor";

export const Route = createFileRoute("/pages/$pageId")({ component: Page });

function Page() {
  return (
    <StudioShell>
      <PageEditor />
    </StudioShell>
  );
}
