import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

export function Badge({
  className,
  tone = "muted",
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: "muted" | "ok" | "warn" | "bad" | "ink" }) {
  const tones = {
    muted: "text-muted border-border",
    ok: "text-ok border-ok/40",
    warn: "text-warn border-warn/40",
    bad: "text-bad border-bad/40",
    ink: "text-ink border-ink/40",
  };
  return (
    <span
      className={cn(
        "inline-flex h-7 items-center rounded-sm border px-2 font-mono text-xs uppercase tracking-wide",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}
