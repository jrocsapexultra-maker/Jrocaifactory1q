import { cn } from "@/lib/utils";

export function Meter({
  value,
  label,
}: {
  value: number;
  label: string;
}) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div className="grid gap-2">
      <div className="flex items-baseline justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-muted">{label}</span>
        <span className="font-mono text-xs tabular-nums text-fg">{v}%</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-elevated">
        <div
          className={cn("h-full rounded-full bg-accent transition-[width] duration-300")}
          style={{ width: `${v}%` }}
        />
      </div>
    </div>
  );
}
