import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Meter } from "@/components/ui/progress";
import { useFactory } from "@/lib/comic/store";

export function FactoryView() {
  const universe = useFactory((s) => s.universe);
  const imageModel = useFactory((s) => s.imageModel);
  const textModel = useFactory((s) => s.textModel);
  const setModels = useFactory((s) => s.setModels);
  const patchJob = useFactory((s) => s.patchJob);

  return (
    <div className="grid gap-8">
      <header>
        <h1 className="font-display text-3xl tracking-tight">Art Factory</h1>
        <p className="text-muted">Free multi-model router. No API keys. Pollinations Flux and Turbo.</p>
      </header>

      <section className="grid gap-4 rounded-xl border border-border bg-surface p-5">
        <h2 className="font-display text-xl">Model router</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="grid gap-2">
            <p className="text-xs uppercase tracking-wide text-muted">Image</p>
            <div className="flex flex-wrap gap-2">
              {(["flux", "turbo"] as const).map((m) => (
                <Button
                  key={m}
                  size="sm"
                  variant={imageModel === m ? "primary" : "outline"}
                  onClick={() => setModels(m, textModel)}
                >
                  {m}
                </Button>
              ))}
            </div>
            <p className="text-sm text-subtle">Flux for finished panels. Turbo for storyboard drafts.</p>
          </div>
          <div className="grid gap-2">
            <p className="text-xs uppercase tracking-wide text-muted">Story / Director</p>
            <div className="flex flex-wrap gap-2">
              {(["openai", "openai-fast"] as const).map((m) => (
                <Button
                  key={m}
                  size="sm"
                  variant={textModel === m ? "primary" : "outline"}
                  onClick={() => setModels(imageModel, m)}
                >
                  {m}
                </Button>
              ))}
            </div>
            <p className="text-sm text-subtle">Free chat models via Pollinations. No paid keys.</p>
          </div>
        </div>
      </section>

      <section className="grid gap-3">
        <h2 className="font-display text-xl">Production queue</h2>
        {universe.jobs.length === 0 ? (
          <p className="text-muted">Queue is empty.</p>
        ) : (
          universe.jobs.map((job) => (
            <article key={job.id} className="grid gap-3 rounded-xl border border-border bg-surface p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium">{job.label}</p>
                <Badge
                  tone={job.status === "done" ? "ok" : job.status === "failed" ? "bad" : job.status === "running" ? "ink" : "muted"}
                >
                  {job.status}
                </Badge>
              </div>
              <Meter label={job.task} value={job.progress} />
              {job.error ? <p className="text-sm text-bad">{job.error}</p> : null}
              <div className="flex flex-wrap gap-2">
                {job.status === "running" ? (
                  <Button size="sm" variant="outline" onClick={() => patchJob(job.id, { status: "paused" })}>
                    Pause
                  </Button>
                ) : null}
                {job.status === "paused" ? (
                  <Button size="sm" variant="outline" onClick={() => patchJob(job.id, { status: "running" })}>
                    Resume
                  </Button>
                ) : null}
                {job.status === "failed" ? (
                  <Button size="sm" variant="outline" onClick={() => patchJob(job.id, { status: "queued", error: undefined })}>
                    Retry
                  </Button>
                ) : null}
              </div>
            </article>
          ))
        )}
      </section>
    </div>
  );
}
