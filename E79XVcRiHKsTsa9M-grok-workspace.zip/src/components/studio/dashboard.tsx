import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Meter } from "@/components/ui/progress";
import { pipelinePercents, useFactory } from "@/lib/comic/store";
import { statusMark, statusTone } from "@/lib/comic/status";

export function Dashboard() {
  const universe = useFactory((s) => s.universe);
  const selectPage = useFactory((s) => s.selectPage);
  const p = pipelinePercents(universe);

  return (
    <div className="grid gap-8">
      <header className="grid gap-2">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">Comic Universe</p>
        <h1 className="font-display text-4xl tracking-tight md:text-5xl">{universe.bible.title}</h1>
        <p className="max-w-2xl text-muted leading-normal">{universe.bible.logline}</p>
      </header>

      <section className="grid gap-6 rounded-xl border border-border bg-surface p-5 md:p-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-wide text-muted">{universe.volume.issue}</p>
            <h2 className="font-display text-2xl">{universe.volume.title}</h2>
          </div>
          <Badge tone="ink">Free model router</Badge>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Meter label="Story" value={p.story} />
          <Meter label="Storyboard" value={p.board} />
          <Meter label="Artwork" value={p.art} />
          <Meter label="Continuity" value={p.cont} />
          <Meter label="Lettering" value={p.letter} />
          <Meter label="Approved" value={p.pub} />
        </div>
      </section>

      <section className="grid gap-4">
        <h2 className="font-display text-xl">Pages</h2>
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-6">
          {universe.pages.map((page) => (
            <Link
              key={page.id}
              to="/pages/$pageId"
              params={{ pageId: page.id }}
              onClick={() => selectPage(page.id)}
              className="flex h-16 flex-col items-center justify-center rounded-md border border-border bg-elevated text-center transition-colors hover:border-accent"
            >
              <span className="font-mono text-sm tabular-nums">
                {String(page.number).padStart(3, "0")}
              </span>
              <Badge tone={statusTone(page.status)} className="mt-1 h-5 border-0 px-1 text-[10px]">
                {statusMark(page.status)} {page.status}
              </Badge>
            </Link>
          ))}
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {universe.characters.map((c) => (
          <Link
            key={c.id}
            to="/characters"
            className="overflow-hidden rounded-xl border border-border bg-surface"
          >
            {c.frontRef ? (
              <img src={c.frontRef} alt="" className="h-56 w-full object-cover object-top" />
            ) : null}
            <div className="p-4">
              <p className="text-xs uppercase tracking-wide text-muted">{c.role}</p>
              <h3 className="font-display text-xl">{c.name}</h3>
            </div>
          </Link>
        ))}
      </section>

      <div className="flex flex-wrap gap-3">
        <Link to="/pages">
          <Button>Generate next page</Button>
        </Link>
        <Link to="/factory">
          <Button variant="outline">Batch generate</Button>
        </Link>
        <Link to="/continuity">
          <Button variant="outline">Continuity</Button>
        </Link>
        <Link to="/publish">
          <Button variant="outline">Export</Button>
        </Link>
      </div>
    </div>
  );
}
