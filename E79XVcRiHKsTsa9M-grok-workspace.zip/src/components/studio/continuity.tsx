import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { buildContinuityState } from "@/lib/comic/continuity";
import { useFactory } from "@/lib/comic/store";
import type { ContinuityEvent } from "@/lib/comic/types";

const FIELDS: ContinuityEvent["field"][] = [
  "costume",
  "injuries",
  "weapons",
  "props",
  "location",
  "weather",
  "timeOfDay",
  "damage",
  "position",
];

export function ContinuityView() {
  const universe = useFactory((s) => s.universe);
  const addEvent = useFactory((s) => s.addEvent);
  const [pageNumber, setPageNumber] = useState(5);
  const [field, setField] = useState<ContinuityEvent["field"]>("costume");
  const [characterId, setCharacterId] = useState("watcher");
  const [value, setValue] = useState("");

  const state = useMemo(
    () => buildContinuityState(universe.events, pageNumber),
    [universe.events, pageNumber],
  );

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="grid gap-4">
        <header>
          <h1 className="font-display text-3xl tracking-tight">Continuity Guardian</h1>
          <p className="text-muted">Canonical state for any page, built from every prior event.</p>
        </header>
        <Field label="Inspect page">
          <Input
            type="number"
            min={1}
            max={universe.volume.pageCount}
            value={pageNumber}
            onChange={(e) => setPageNumber(Number(e.target.value))}
          />
        </Field>
        <dl className="grid gap-3 rounded-xl border border-border bg-surface p-5 text-sm">
          <Row k="Location" v={state.location} />
          <Row k="Weather" v={state.weather} />
          <Row k="Time" v={state.timeOfDay} />
          <Row k="Damage" v={state.damage} />
          {universe.characters.map((c) => (
            <div key={c.id} className="border-t border-border pt-3">
              <p className="font-medium">{c.name}</p>
              <p className="text-muted">Costume: {state.costume[c.id] || c.costume}</p>
              <p className="text-muted">Injury: {state.injuries[c.id] || "none"}</p>
              <p className="text-muted">Weapon: {state.weapons[c.id] || c.weapons}</p>
            </div>
          ))}
        </dl>
      </div>
      <div className="grid gap-4">
        <h2 className="font-display text-xl">Log an event</h2>
        <Field label="Field">
          <select
            className="h-11 rounded-sm border border-border bg-bg px-3 text-sm"
            value={field}
            onChange={(e) => setField(e.target.value as ContinuityEvent["field"])}
          >
            {FIELDS.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Character">
          <select
            className="h-11 rounded-sm border border-border bg-bg px-3 text-sm"
            value={characterId}
            onChange={(e) => setCharacterId(e.target.value)}
          >
            {universe.characters.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Value">
          <Input value={value} onChange={(e) => setValue(e.target.value)} placeholder="Damaged V2" />
        </Field>
        <Button
          onClick={() => {
            if (!value.trim()) return;
            addEvent({ pageNumber, field, value, characterId });
            setValue("");
          }}
        >
          Record event
        </Button>
        <ol className="grid gap-2">
          {universe.events
            .slice()
            .sort((a, b) => a.pageNumber - b.pageNumber)
            .map((e) => (
              <li key={e.id} className="rounded-md border border-border bg-surface px-3 py-2 text-sm">
                <span className="font-mono text-ink">p{String(e.pageNumber).padStart(2, "0")}</span>{" "}
                {e.field} · {e.value}
              </li>
            ))}
        </ol>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-4">
      <dt className="text-muted">{k}</dt>
      <dd className="text-right">{v || "—"}</dd>
    </div>
  );
}
