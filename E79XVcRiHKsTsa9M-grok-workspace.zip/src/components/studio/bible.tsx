import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Field, Textarea, Input } from "@/components/ui/field";
import { useFactory } from "@/lib/comic/store";
import { writeStory } from "@/lib/comic/ai";
import { toast } from "sonner";

export function BibleView() {
  const universe = useFactory((s) => s.universe);
  const setStory = useFactory((s) => s.setStory);
  const updateBible = useFactory((s) => s.updateBible);
  const updateStyle = useFactory((s) => s.updateStyle);
  const textModel = useFactory((s) => s.textModel);
  const [tab, setTab] = useState<"universe" | "story" | "style">("universe");
  const [instruction, setInstruction] = useState("Tighten chapter two so Nyx arrives earlier.");
  const [busy, setBusy] = useState(false);

  async function expandStory() {
    setBusy(true);
    const res = await writeStory({
      data: {
        bible: `${universe.bible.premise}\nRules:\n${universe.bible.rules.join("\n")}`,
        current: universe.story,
        instruction,
        model: textModel,
      },
    });
    setBusy(false);
    if (!res.ok) {
      toast.error(res.error);
      return;
    }
    setStory(res.text);
    toast.success(`Story rewritten with ${res.model}`);
  }

  return (
    <div className="grid gap-6">
      <header>
        <h1 className="font-display text-3xl tracking-tight">Universe Bible</h1>
        <p className="text-muted">Lore, story, and the style lock for every generation.</p>
      </header>
      <div className="flex flex-wrap gap-2">
        {(["universe", "story", "style"] as const).map((t) => (
          <Button key={t} variant={tab === t ? "primary" : "outline"} size="sm" onClick={() => setTab(t)}>
            {t}
          </Button>
        ))}
      </div>

      {tab === "universe" ? (
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="grid gap-4 rounded-xl border border-border bg-surface p-5">
            <Field label="Logline">
              <Textarea value={universe.bible.logline} onChange={(e) => updateBible({ logline: e.target.value })} />
            </Field>
            <Field label="Premise">
              <Textarea value={universe.bible.premise} onChange={(e) => updateBible({ premise: e.target.value })} />
            </Field>
          </div>
          <div className="grid gap-4">
            <section className="rounded-xl border border-border bg-surface p-5">
              <h2 className="mb-3 font-display text-xl">Rules</h2>
              <ul className="grid gap-2 text-sm leading-normal text-muted">
                {universe.bible.rules.map((r) => (
                  <li key={r} className="border-l-2 border-ink pl-3">
                    {r}
                  </li>
                ))}
              </ul>
            </section>
            <section className="rounded-xl border border-border bg-surface p-5">
              <h2 className="mb-3 font-display text-xl">Timeline</h2>
              <ol className="grid gap-2">
                {universe.bible.timeline.map((t) => (
                  <li key={t.year} className="flex gap-4 text-sm">
                    <span className="font-mono text-ink">{t.year}</span>
                    <span className="text-muted">{t.event}</span>
                  </li>
                ))}
              </ol>
            </section>
            <section className="rounded-xl border border-border bg-surface p-5">
              <h2 className="mb-3 font-display text-xl">Factions</h2>
              <ul className="grid gap-3">
                {universe.bible.factions.map((f) => (
                  <li key={f.name}>
                    <p className="font-medium">{f.name}</p>
                    <p className="text-sm text-muted">{f.note}</p>
                  </li>
                ))}
              </ul>
            </section>
          </div>
        </div>
      ) : null}

      {tab === "story" ? (
        <div className="grid gap-4">
          <Field label="Story bible">
            <Textarea className="min-h-56" value={universe.story} onChange={(e) => setStory(e.target.value)} />
          </Field>
          <Field label="Director instruction">
            <Input value={instruction} onChange={(e) => setInstruction(e.target.value)} />
          </Field>
          <Button onClick={expandStory} disabled={busy}>
            {busy ? "Writing with free model…" : "Rewrite with free story model"}
          </Button>
        </div>
      ) : null}

      {tab === "style" ? (
        <div className="grid gap-4 md:grid-cols-2">
          {(
            [
              ["name", universe.style.name],
              ["line", universe.style.line],
              ["color", universe.style.color],
              ["lighting", universe.style.lighting],
              ["camera", universe.style.camera],
              ["lettering", universe.style.lettering],
              ["references", universe.style.references],
            ] as const
          ).map(([key, value]) => (
            <Field key={key} label={key}>
              <Textarea
                value={value}
                onChange={(e) => updateStyle({ [key]: e.target.value })}
              />
            </Field>
          ))}
        </div>
      ) : null}
    </div>
  );
}
