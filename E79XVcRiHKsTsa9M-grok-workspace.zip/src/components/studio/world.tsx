import { Field, Input, Textarea } from "@/components/ui/field";
import { useFactory } from "@/lib/comic/store";

export function WorldView() {
  const universe = useFactory((s) => s.universe);
  const upsertLocation = useFactory((s) => s.upsertLocation);
  const upsertProp = useFactory((s) => s.upsertProp);

  return (
    <div className="grid gap-10">
      <header>
        <h1 className="font-display text-3xl tracking-tight">Locations & Props</h1>
        <p className="text-muted">World DNA injected into every panel that visits these places.</p>
      </header>
      <section className="grid gap-4">
        <h2 className="font-display text-xl">Location DNA</h2>
        <div className="grid gap-4 md:grid-cols-2">
          {universe.locations.map((loc) => (
            <article key={loc.id} className="overflow-hidden rounded-xl border border-border bg-surface">
              {loc.image ? <img src={loc.image} alt="" className="h-40 w-full object-cover" /> : null}
              <div className="grid gap-3 p-4">
                <Field label="Name">
                  <Input value={loc.name} onChange={(e) => upsertLocation({ ...loc, name: e.target.value })} />
                </Field>
                <Field label="Atmosphere">
                  <Textarea value={loc.atmosphere} onChange={(e) => upsertLocation({ ...loc, atmosphere: e.target.value })} />
                </Field>
                <Field label="Lighting">
                  <Input value={loc.lighting} onChange={(e) => upsertLocation({ ...loc, lighting: e.target.value })} />
                </Field>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="grid gap-4">
        <h2 className="font-display text-xl">Prop library</h2>
        <div className="grid gap-3">
          {universe.props.map((p) => (
            <article key={p.id} className="grid gap-3 rounded-xl border border-border bg-surface p-4 md:grid-cols-3">
              <Field label="Name">
                <Input value={p.name} onChange={(e) => upsertProp({ ...p, name: e.target.value })} />
              </Field>
              <Field label="State">
                <Input value={p.state} onChange={(e) => upsertProp({ ...p, state: e.target.value })} />
              </Field>
              <Field label="Description">
                <Input value={p.description} onChange={(e) => upsertProp({ ...p, description: e.target.value })} />
              </Field>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
