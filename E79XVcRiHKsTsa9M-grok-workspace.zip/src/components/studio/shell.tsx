import { Link, useRouterState } from "@tanstack/react-router";
import {
  BookOpen,
  Camera,
  Factory,
  LayoutGrid,
  Map,
  Menu,
  ShieldCheck,
  Type,
  Users,
  Download,
  GitBranch,
  X,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useFactory } from "@/lib/comic/store";

const NAV = [
  { to: "/", label: "Studio", icon: LayoutGrid },
  { to: "/bible", label: "Universe Bible", icon: BookOpen },
  { to: "/characters", label: "Character DNA", icon: Users },
  { to: "/world", label: "Locations / Props", icon: Map },
  { to: "/pages", label: "Pages", icon: Camera },
  { to: "/factory", label: "Art Factory", icon: Factory },
  { to: "/continuity", label: "Continuity", icon: GitBranch },
  { to: "/lettering", label: "Lettering", icon: Type },
  { to: "/qc", label: "Quality Control", icon: ShieldCheck },
  { to: "/publish", label: "Publish", icon: Download },
];

export function StudioShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const universe = useFactory((s) => s.universe);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    void useFactory.persist.rehydrate();
  }, []);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="no-print sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-bg px-4 md:px-6">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu className="size-5" />
          </Button>
          <Link to="/" className="flex items-baseline gap-2">
            <span className="font-display text-lg tracking-tight">JROCAI</span>
            <span className="text-xs uppercase tracking-[0.2em] text-muted">Factory</span>
          </Link>
        </div>
        <div className="hidden items-center gap-4 md:flex">
          <span className="text-xs uppercase tracking-wide text-muted">Project</span>
          <span className="font-medium">{universe.name}</span>
          <span className="text-muted">/</span>
          <span className="font-mono text-xs">{universe.volume.issue}</span>
        </div>
        <span className="rounded-sm border border-border px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-ink">
          Elite
        </span>
      </header>

      <div className="mx-auto flex max-w-[1600px]">
        <aside className="no-print sticky top-14 hidden h-[calc(100dvh-3.5rem)] w-56 shrink-0 overflow-y-auto border-r border-border p-3 md:block">
          <Nav pathname={pathname} />
        </aside>

        <main className="min-w-0 flex-1 p-4 md:p-8">{children}</main>
      </div>

      {open ? (
        <div className="fixed inset-0 z-40 md:hidden">
          <button className="absolute inset-0 bg-bg/80" onClick={() => setOpen(false)} aria-label="Close menu" />
          <div className="absolute inset-y-0 left-0 flex w-72 flex-col gap-2 border-r border-border bg-surface p-4">
            <div className="flex items-center justify-between">
              <span className="font-display text-lg">Menu</span>
              <Button variant="ghost" size="icon" onClick={() => setOpen(false)} aria-label="Close">
                <X className="size-5" />
              </Button>
            </div>
            <Nav pathname={pathname} onNavigate={() => setOpen(false)} />
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Nav({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  return (
    <nav className="grid gap-1">
      {NAV.map((item) => {
        const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            className={cn(
              "flex h-11 items-center gap-3 rounded-sm px-3 text-sm transition-colors duration-150",
              active ? "bg-elevated text-fg" : "text-muted hover:bg-elevated hover:text-fg",
            )}
          >
            <Icon className="size-4 shrink-0" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
