import { Link, useParams } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, Textarea } from "@/components/ui/field";
import { askDirector, generatePanelArt } from "@/lib/comic/ai";
import { buildContinuityState } from "@/lib/comic/continuity";
import { buildPanelPrompt } from "@/lib/comic/prompts";
import { statusTone } from "@/lib/comic/status";
import { useFactory } from "@/lib/comic/store";
import type { Panel, ShotType } from "@/lib/comic/types";

export function PageEditor() {
  const { pageId } = useParams({ from: "/pages/$pageId" });
  const universe = useFactory((s) => s.universe);
  const imageModel = useFactory((s) => s.imageModel);
  const textModel = useFactory((s) => s.textModel);
  const applyDirectorPlan = useFactory((s) => s.applyDirectorPlan);
  const updatePanel = useFactory((s) => s.updatePanel);
  const addGeneration = useFactory((s) => s.addGeneration);
  const selectGeneration = useFactory((s) => s.selectGeneration);
  const enqueueJob = useFactory((s) => s.enqueueJob);
  const patchJob = useFactory((s) => s.patchJob);
  const setPageStatus = useFactory((s) => s.setPageStatus);
  const [busy, setBusy] = useState<string | null>(null);

  const page = universe.pages.find((p) => p.id === pageId);
  if (!page) {
    return (
      <div className="grid gap-3">
        <p>Page not found.</p>
        <Link to="/pages" className="text-ink underline">
          Back to pages
        </Link>
      </div>
    );
  }

  const state = buildContinuityState(universe.events, page.number);

  async function runDirector() {
    if (!page) return;
    setBusy("director");
    const res = await askDirector({
      data: {
        brief: `${universe.story}\n\nPage brief: ${page.script}\nStyle: ${universe.style.line} ${universe.style.color}\nContinuity location ${state.location}, weather ${state.weather}.`,
        pageNumber: page.number,
        pageType: page.type,
        model: textModel,
      },
    });
    setBusy(null);
    if (!res.ok) {
      toast.error(res.error);
      return;
    }
    const panels: Panel[] = (res.plan.panels ?? []).slice(0, 6).map((p, i) => ({
      id: `${page.id}-${i + 1}`,
      number: i + 1,
      shot: (p.shot as ShotType) || "medium",
      camera: p.camera,
      action: p.action,
      description: p.description,
      dialogue: p.dialogue ?? "",
      speaker: p.speaker,
      caption: p.caption ?? "",
      sfx: p.sfx ?? "",
      prompt: "",
      negative: "text, watermark, extra fingers, deformed anatomy",
      balloonX: 16 + (i % 3) * 22,
      balloonY: 12 + (i % 2) * 28,
    }));
    applyDirectorPlan(page.id, panels, page.type, res.plan.script ?? page.script);
    toast.success(`Director planned ${panels.length} panels with ${res.model}`);
  }

  async function generatePanel(panel: Panel) {
    if (!page) return;
    const prompt = buildPanelPrompt({
      panel,
      page,
      style: universe.style,
      characters: universe.characters,
      state,
    });
    const jobId = enqueueJob({
      label: `Page ${String(page.number).padStart(3, "0")} / Panel ${panel.number}`,
      task: "comic_panel",
      status: "running",
      progress: 15,
      pageId: page.id,
      panelId: panel.id,
    });
    setPageStatus(page.id, "generating");
    setBusy(panel.id);
    const seed = Math.floor(Math.random() * 1_000_000);
    const res = await generatePanelArt({
      data: {
        prompt,
        model: imageModel,
        width: 1024,
        height: page.type === "COVER" || page.type === "SPLASH" ? 1536 : 1024,
        seed,
      },
    });
    setBusy(null);
    if (!res.ok) {
      patchJob(jobId, { status: "failed", error: res.error, progress: 0 });
      toast.error(res.error);
      return;
    }
    const genId = `g-${panel.id}-${seed}`;
    addGeneration({
      id: genId,
      panelId: panel.id,
      pageId: page.id,
      model: `pollinations-${res.model}`,
      prompt,
      image: res.url,
      seed: res.seed,
      status: "done",
      createdAt: new Date().toISOString(),
      note: "v1",
    });
    selectGeneration(page.id, panel.id, genId);
    updatePanel(page.id, panel.id, { prompt });
    patchJob(jobId, { status: "done", progress: 100 });
    toast.success(`Panel ${panel.number} via ${res.model}`);
  }

  const gens = universe.generations.filter((g) => g.pageId === page.id);

  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs text-muted">
            PAGE {String(page.number).padStart(3, "0")} · {page.type}
          </p>
          <h1 className="font-display text-3xl tracking-tight">{page.title}</h1>
        </div>
        <Badge tone={statusTone(page.status)}>{page.status}</Badge>
      </div>

      <div className="grid gap-4 rounded-xl border border-border bg-surface p-5">
        <p className="text-sm text-muted">{page.script}</p>
        <p className="text-xs text-subtle">
          Continuity · {state.location || "unknown"} · {state.weather || "—"} · {state.timeOfDay || "—"}
        </p>
        <div className="flex flex-wrap gap-2">
          <Button onClick={runDirector} disabled={busy === "director"}>
            {busy === "director" ? "Directing…" : "Comic Director (free)"}
          </Button>
          <Button
            variant="outline"
            onClick={() => page.panels.forEach((p) => void generatePanel(p))}
            disabled={!!busy}
          >
            Generate all panels
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {page.panels.map((panel) => {
          const selected = gens.find((g) => g.id === panel.selectedGenerationId);
          return (
            <article key={panel.id} className="overflow-hidden rounded-xl border border-border bg-surface">
              <div className="relative aspect-[4/3] bg-elevated">
                {selected?.image ? (
                  <img src={selected.image} alt="" className="h-full w-full object-cover" />
                ) : page.finalImage && panel.number === 1 ? (
                  <img src={page.finalImage} alt="" className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full flex-col items-center justify-center gap-1 p-4 text-center">
                    <span className="font-mono text-xs text-muted">
                      {panel.shot} · {panel.camera}
                    </span>
                    <span className="text-sm text-subtle">{panel.action}</span>
                  </div>
                )}
                {panel.dialogue ? (
                  <div
                    className="absolute max-w-[70%] rounded-md bg-accent px-2 py-1 text-xs text-accent-fg"
                    style={{ left: `${panel.balloonX}%`, top: `${panel.balloonY}%` }}
                  >
                    {panel.dialogue}
                  </div>
                ) : null}
                {panel.sfx ? (
                  <span className="absolute bottom-3 right-3 font-display text-lg text-ink">{panel.sfx}</span>
                ) : null}
              </div>
              <div className="grid gap-3 p-4">
                <div className="flex items-center justify-between">
                  <p className="font-mono text-xs">PANEL {String(panel.number).padStart(2, "0")}</p>
                  <Button size="sm" onClick={() => generatePanel(panel)} disabled={busy === panel.id}>
                    {busy === panel.id ? "Flux…" : `Generate · ${imageModel}`}
                  </Button>
                </div>
                <Field label="Action">
                  <Textarea
                    value={panel.action}
                    onChange={(e) => updatePanel(page.id, panel.id, { action: e.target.value })}
                  />
                </Field>
                <Field label="Dialogue">
                  <Textarea
                    value={panel.dialogue}
                    onChange={(e) => updatePanel(page.id, panel.id, { dialogue: e.target.value })}
                  />
                </Field>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
