import { useFactory } from "@/lib/comic/store";
import { Field, Input } from "@/components/ui/field";
import { Button } from "@/components/ui/button";

export function LetteringView() {
  const universe = useFactory((s) => s.universe);
  const selectedPageId = useFactory((s) => s.selectedPageId);
  const selectPage = useFactory((s) => s.selectPage);
  const updatePanel = useFactory((s) => s.updatePanel);
  const toggleQc = useFactory((s) => s.toggleQc);
  const page = universe.pages.find((p) => p.id === selectedPageId) ?? universe.pages[0];

  if (!page) return null;

  return (
    <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
      <aside className="grid h-fit gap-1">
        {universe.pages.map((p) => (
          <button
            key={p.id}
            onClick={() => selectPage(p.id)}
            className={`h-11 rounded-sm px-3 text-left font-mono text-sm ${p.id === page.id ? "bg-elevated" : "text-muted hover:bg-elevated"}`}
          >
            {String(p.number).padStart(3, "0")} {p.title}
          </button>
        ))}
      </aside>
      <div className="grid gap-4">
        <header>
          <h1 className="font-display text-3xl tracking-tight">Lettering Studio</h1>
          <p className="text-muted">Balloons, captions, SFX. Placement is stored per panel.</p>
        </header>
        {page.panels.map((panel) => (
          <article key={panel.id} className="grid gap-3 rounded-xl border border-border bg-surface p-4 md:grid-cols-2">
            <Field label={`Panel ${panel.number} dialogue`}>
              <Input
                value={panel.dialogue}
                onChange={(e) => updatePanel(page.id, panel.id, { dialogue: e.target.value })}
              />
            </Field>
            <Field label="Caption">
              <Input
                value={panel.caption}
                onChange={(e) => updatePanel(page.id, panel.id, { caption: e.target.value })}
              />
            </Field>
            <Field label="SFX">
              <Input value={panel.sfx} onChange={(e) => updatePanel(page.id, panel.id, { sfx: e.target.value })} />
            </Field>
            <Field label="Balloon X / Y %">
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  value={panel.balloonX}
                  onChange={(e) => updatePanel(page.id, panel.id, { balloonX: Number(e.target.value) })}
                />
                <Input
                  type="number"
                  value={panel.balloonY}
                  onChange={(e) => updatePanel(page.id, panel.id, { balloonY: Number(e.target.value) })}
                />
              </div>
            </Field>
          </article>
        ))}
        <Button variant="outline" onClick={() => toggleQc(page.id, "lettering")}>
          {page.qc.lettering ? "Lettering approved" : "Mark lettering approved"}
        </Button>
      </div>
    </div>
  );
}
