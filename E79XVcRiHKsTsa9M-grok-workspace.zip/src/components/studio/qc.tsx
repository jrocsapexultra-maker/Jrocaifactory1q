import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useFactory } from "@/lib/comic/store";

const CHECKS = ["art", "character", "continuity", "lettering", "bleed"] as const;

export function QcView() {
  const universe = useFactory((s) => s.universe);
  const toggleQc = useFactory((s) => s.toggleQc);
  const setPageStatus = useFactory((s) => s.setPageStatus);

  return (
    <div className="grid gap-6">
      <header>
        <h1 className="font-display text-3xl tracking-tight">Review Board</h1>
        <p className="text-muted">A page is published only when every check is green.</p>
      </header>
      <div className="grid gap-3">
        {universe.pages.map((page) => {
          const ready = CHECKS.every((k) => page.qc[k]);
          return (
            <article key={page.id} className="grid gap-3 rounded-xl border border-border bg-surface p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium">
                  {String(page.number).padStart(3, "0")} {page.title}
                </p>
                <Badge tone={ready ? "ok" : page.qc.flags.length ? "warn" : "muted"}>
                  {ready ? "ready" : page.qc.flags[0] || page.status}
                </Badge>
              </div>
              <div className="flex flex-wrap gap-2">
                {CHECKS.map((k) => (
                  <Button
                    key={k}
                    size="sm"
                    variant={page.qc[k] ? "primary" : "outline"}
                    onClick={() => toggleQc(page.id, k)}
                  >
                    {k} {page.qc[k] ? "yes" : "no"}
                  </Button>
                ))}
              </div>
              {ready ? (
                <Button size="sm" onClick={() => setPageStatus(page.id, "published")}>
                  Publish page
                </Button>
              ) : null}
            </article>
          );
        })}
      </div>
    </div>
  );
}
