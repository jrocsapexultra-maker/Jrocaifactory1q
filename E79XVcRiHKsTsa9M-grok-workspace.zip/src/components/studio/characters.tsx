import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/field";
import { useFactory } from "@/lib/comic/store";
import type { CharacterDNA } from "@/lib/comic/types";

export function CharactersView() {
  const universe = useFactory((s) => s.universe);
  const selected = useFactory((s) => s.selectedCharacterId);
  const selectCharacter = useFactory((s) => s.selectCharacter);
  const upsertCharacter = useFactory((s) => s.upsertCharacter);
  const char = universe.characters.find((c) => c.id === selected) ?? universe.characters[0];

  function patch(p: Partial<CharacterDNA>) {
    if (!char) return;
    upsertCharacter({ ...char, ...p });
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
      <aside className="grid h-fit gap-2">
        {universe.characters.map((c) => (
          <button
            key={c.id}
            onClick={() => selectCharacter(c.id)}
            className={`rounded-md border px-3 py-3 text-left ${c.id === char?.id ? "border-accent bg-elevated" : "border-border bg-surface"}`}
          >
            <p className="text-xs text-muted">{c.role}</p>
            <p className="font-medium">{c.name}</p>
          </button>
        ))}
        <Button
          variant="outline"
          onClick={() => {
            const id = `char-${Date.now()}`;
            upsertCharacter({
              id,
              name: "New character",
              role: "Supporting",
              physical: "",
              face: "",
              body: "",
              hair: "",
              eyes: "",
              skin: "",
              costume: "",
              footwear: "",
              accessories: "",
              weapons: "",
              signature: "",
              palette: "",
              personality: "",
              voice: "",
            });
            selectCharacter(id);
          }}
        >
          Add DNA
        </Button>
      </aside>

      {char ? (
        <div className="grid gap-6">
          <div className="overflow-hidden rounded-xl border border-border bg-surface md:grid md:grid-cols-[280px_1fr]">
            {char.frontRef ? (
              <img src={char.frontRef} alt="" className="h-80 w-full object-cover object-top md:h-full" />
            ) : (
              <div className="flex h-48 items-center justify-center bg-elevated text-sm text-muted">No front reference</div>
            )}
            <div className="grid gap-4 p-5">
              <Field label="Name">
                <Input value={char.name} onChange={(e) => patch({ name: e.target.value })} />
              </Field>
              <Field label="Role">
                <Input value={char.role} onChange={(e) => patch({ role: e.target.value })} />
              </Field>
              <Field label="Signature features">
                <Input value={char.signature} onChange={(e) => patch({ signature: e.target.value })} />
              </Field>
              <Field label="Color palette">
                <Input value={char.palette} onChange={(e) => patch({ palette: e.target.value })} />
              </Field>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {(
              [
                ["face", char.face],
                ["body", char.body],
                ["hair", char.hair],
                ["eyes", char.eyes],
                ["skin", char.skin],
                ["physical", char.physical],
                ["costume", char.costume],
                ["footwear", char.footwear],
                ["accessories", char.accessories],
                ["weapons", char.weapons],
                ["personality", char.personality],
                ["voice", char.voice],
              ] as const
            ).map(([key, value]) => (
              <Field key={key} label={key}>
                <Textarea value={value} onChange={(e) => patch({ [key]: e.target.value })} />
              </Field>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}
