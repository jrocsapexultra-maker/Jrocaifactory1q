import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { useFactory } from "@/lib/comic/store";
import { statusTone } from "@/lib/comic/status";

export function PagesGrid() {
  const universe = useFactory((s) => s.universe);
  const selectPage = useFactory((s) => s.selectPage);

  return (
    <div className="grid gap-6">
      <header>
        <h1 className="font-display text-3xl tracking-tight">Volume pages</h1>
        <p className="text-muted">
          {universe.volume.title} · {universe.volume.pageCount} pages · {universe.pages.reduce((n, p) => n + p.panels.length, 0)} panels
        </p>
      </header>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {universe.pages.map((page) => (
          <Link
            key={page.id}
            to="/pages/$pageId"
            params={{ pageId: page.id }}
            onClick={() => selectPage(page.id)}
            className="overflow-hidden rounded-xl border border-border bg-surface"
          >
            <div className="relative h-56 bg-elevated">
              {page.finalImage ? (
                <img src={page.finalImage} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center font-mono text-muted">
                  {page.layout}
                </div>
              )}
              <span className="absolute left-3 top-3 font-mono text-xs tabular-nums text-accent-fg bg-accent px-2 py-1 rounded-sm">
                {String(page.number).padStart(3, "0")}
              </span>
            </div>
            <div className="flex items-center justify-between gap-2 p-4">
              <div>
                <p className="font-medium">{page.title}</p>
                <p className="text-xs uppercase tracking-wide text-muted">{page.type}</p>
              </div>
              <Badge tone={statusTone(page.status)}>{page.status}</Badge>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
