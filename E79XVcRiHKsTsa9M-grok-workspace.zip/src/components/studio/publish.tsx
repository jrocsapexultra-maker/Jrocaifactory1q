import { Button } from "@/components/ui/button";
import { useFactory } from "@/lib/comic/store";

export function PublishView() {
  const universe = useFactory((s) => s.universe);
  const resetUniverse = useFactory((s) => s.resetUniverse);

  function exportJson() {
    const blob = new Blob([JSON.stringify(universe, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${universe.name.toLowerCase()}-vol01.json`;
    a.click();
  }

  function exportWeb() {
    window.print();
  }

  return (
    <div className="grid gap-8">
      <header>
        <h1 className="font-display text-3xl tracking-tight">Publishing</h1>
        <p className="text-muted">PNG pages, print, web edition, and a JSON archive for CBZ assembly.</p>
      </header>
      <div className="flex flex-wrap gap-3 no-print">
        <Button onClick={exportWeb}>Print / PDF</Button>
        <Button variant="outline" onClick={exportJson}>
          Download JSON / CBZ source
        </Button>
        <Button variant="outline" onClick={resetUniverse}>
          Reset universe
        </Button>
      </div>
      <article className="grid gap-8">
        {universe.pages.map((page) => (
          <section key={page.id} className="break-inside-avoid overflow-hidden rounded-xl border border-border bg-surface">
            {page.finalImage ? (
              <img src={page.finalImage} alt="" className="w-full object-cover" />
            ) : (
              <div className="grid gap-2 p-6">
                {page.panels.map((panel) => (
                  <div key={panel.id} className="rounded-md border border-border p-4">
                    <p className="font-mono text-xs text-muted">Panel {panel.number}</p>
                    <p>{panel.action}</p>
                    {panel.dialogue ? <p className="mt-2 italic">{panel.dialogue}</p> : null}
                  </div>
                ))}
              </div>
            )}
            <div className="flex items-center justify-between p-3 text-xs uppercase tracking-wide text-muted">
              <span>
                {universe.name} · {String(page.number).padStart(3, "0")}
              </span>
              <span>{page.type}</span>
            </div>
          </section>
        ))}
      </article>
    </div>
  );
}
