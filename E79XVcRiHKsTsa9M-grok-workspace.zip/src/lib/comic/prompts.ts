import type { CharacterDNA, ContinuityState, StyleBible, ComicPage, Panel } from "./types";

export function characterPrompt(c: CharacterDNA, costumeOverride?: string) {
  return [
    c.name,
    c.face,
    c.body,
    `hair: ${c.hair}`,
    `eyes: ${c.eyes}`,
    `wearing: ${costumeOverride ?? c.costume}`,
    c.footwear,
    c.accessories,
    `signature: ${c.signature}`,
    `palette: ${c.palette}`,
  ]
    .filter(Boolean)
    .join(", ");
}

export function buildPanelPrompt(opts: {
  panel: Panel;
  page: ComicPage;
  style: StyleBible;
  characters: CharacterDNA[];
  state: ContinuityState;
}): string {
  const { panel, page, style, characters, state } = opts;
  const dna = characters.map((c) => characterPrompt(c, state.costume[c.id])).join(" | ");
  const cont = [
    state.location && `location: ${state.location}`,
    state.weather && `weather: ${state.weather}`,
    state.timeOfDay && `time: ${state.timeOfDay}`,
    state.damage && `environment: ${state.damage}`,
    ...Object.entries(state.injuries).map(([id, v]) => {
      const name = characters.find((c) => c.id === id)?.name ?? id;
      return `${name} injury: ${v}`;
    }),
    ...Object.entries(state.weapons).map(([id, v]) => {
      const name = characters.find((c) => c.id === id)?.name ?? id;
      return `${name} weapon: ${v}`;
    }),
  ]
    .filter(Boolean)
    .join("; ");

  return [
    "western comic book panel, print coloring, bold black ink, high contrast",
    style.line,
    style.color,
    style.lighting,
    `page type ${page.type}, shot ${panel.shot}, camera ${panel.camera}`,
    panel.action,
    panel.description,
    dna,
    cont,
    "no captions, no speech balloons, no watermark, no extra limbs",
  ]
    .filter(Boolean)
    .join(". ");
}
