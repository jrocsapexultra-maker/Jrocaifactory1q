import type { ContinuityEvent, ContinuityState } from "./types";

export function emptyState(): ContinuityState {
  return {
    costume: {},
    injuries: {},
    weapons: {},
    props: [],
    vehicles: [],
    location: "",
    weather: "",
    timeOfDay: "",
    damage: "",
    position: {},
  };
}

export function buildContinuityState(
  events: ContinuityEvent[],
  pageNumber: number,
): ContinuityState {
  const state = emptyState();
  const applicable = events
    .filter((e) => e.pageNumber <= pageNumber)
    .sort((a, b) => a.pageNumber - b.pageNumber);

  for (const e of applicable) {
    switch (e.field) {
      case "costume":
        if (e.characterId) state.costume[e.characterId] = e.value;
        break;
      case "injuries":
        if (e.characterId) state.injuries[e.characterId] = e.value;
        break;
      case "weapons":
        if (e.characterId) state.weapons[e.characterId] = e.value;
        break;
      case "props":
        state.props = [...new Set([...state.props, e.value])];
        break;
      case "vehicles":
        state.vehicles = [...new Set([...state.vehicles, e.value])];
        break;
      case "location":
        state.location = e.value;
        break;
      case "weather":
        state.weather = e.value;
        break;
      case "timeOfDay":
        state.timeOfDay = e.value;
        break;
      case "damage":
        state.damage = e.value;
        break;
      case "position":
        if (e.characterId) state.position[e.characterId] = e.value;
        break;
    }
  }
  return state;
}

export function flagContinuityConflicts(
  events: ContinuityEvent[],
  pageNumber: number,
  proposed: { characterId: string; field: ContinuityEvent["field"]; value: string },
): string | null {
  const state = buildContinuityState(events, pageNumber);
  if (proposed.field === "costume") {
    const current = state.costume[proposed.characterId];
    if (current && current !== proposed.value && !proposed.value.includes(current)) {
      return `Costume conflict: last known is "${current}", prompt asks for "${proposed.value}".`;
    }
  }
  if (proposed.field === "injuries") {
    const current = state.injuries[proposed.characterId];
    if (current && current !== "none" && proposed.value === "none") {
      return `Injury conflict: character still carries "${current}".`;
    }
  }
  return null;
}
