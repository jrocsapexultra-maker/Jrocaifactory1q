import { createServerFn } from "@tanstack/react-start";

export type ImageModel = "flux" | "turbo";
export type TextModel = "openai" | "openai-fast";

const TEXT_URL = "https://text.pollinations.ai/openai";
const IMAGE_BASE = "https://image.pollinations.ai/prompt";

export function buildFreeImageUrl(opts: {
  prompt: string;
  model?: ImageModel;
  width?: number;
  height?: number;
  seed?: number;
}) {
  const prompt = encodeURIComponent(opts.prompt.slice(0, 1400));
  const width = opts.width ?? 1024;
  const height = opts.height ?? 1024;
  const model = opts.model ?? "flux";
  const seed = opts.seed ?? Math.floor(Math.random() * 1_000_000);
  return `${IMAGE_BASE}/${prompt}?width=${width}&height=${height}&nologo=true&enhance=true&model=${model}&seed=${seed}`;
}

async function freeChat(opts: {
  system: string;
  user: string;
  model?: TextModel;
  json?: boolean;
}): Promise<{ ok: true; text: string } | { ok: false; error: string }> {
  const res = await fetch(TEXT_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: opts.model ?? "openai",
      messages: [
        { role: "system", content: opts.system },
        { role: "user", content: opts.user },
      ],
      seed: Math.floor(Math.random() * 10000),
    }),
  });
  if (!res.ok) {
    const fallback = await fetch(
      `https://text.pollinations.ai/${encodeURIComponent(`${opts.system}\n\n${opts.user}`)}?model=${opts.model ?? "openai"}`,
    );
    if (!fallback.ok) return { ok: false, error: `Free model error ${res.status}` };
    return { ok: true, text: await fallback.text() };
  }
  const body = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
    content?: string;
  };
  const text = body.choices?.[0]?.message?.content ?? body.content ?? "";
  if (!text) return { ok: false, error: "Empty response from free model" };
  return { ok: true, text };
}

export const listFreeModels = createServerFn({ method: "POST" }).handler(async () => {
  return {
    image: [
      { id: "flux", label: "Flux (Pollinations)", cost: "Free", bestFor: "Comic panels, characters" },
      { id: "turbo", label: "Turbo (Pollinations)", cost: "Free", bestFor: "Fast drafts" },
    ],
    text: [
      { id: "openai", label: "OpenAI via Pollinations", cost: "Free", bestFor: "Director / story" },
      { id: "openai-fast", label: "OpenAI Fast", cost: "Free", bestFor: "Quick rewrites" },
    ],
    router: ["pollinations-flux", "pollinations-turbo"],
  };
});

export const askDirector = createServerFn({ method: "POST" })
  .validator((input: { brief: string; pageNumber: number; pageType: string; model?: TextModel }) => input)
  .handler(async ({ data }) => {
    const result = await freeChat({
      model: data.model ?? "openai",
      system:
        "You are the Comic Director for WATCHERS, a rain-soaked western comic. Reply with JSON only, no markdown. Shape: { pageType, script, panels: [{ number, shot, camera, action, description, dialogue, speaker, caption, sfx }] }. 1-6 panels. Shots: establishing|wide|full|medium|close|extreme-close|over-shoulder|insert|bird|worm.",
      user: `Page ${data.pageNumber} type ${data.pageType}. Brief:\n${data.brief}`,
    });
    if (!result.ok) return result;
    const text = result.text;
    const jsonStart = text.indexOf("{");
    const jsonEnd = text.lastIndexOf("}");
    if (jsonStart < 0 || jsonEnd < 0) return { ok: false as const, error: "Director returned no JSON" };
    try {
      const plan = JSON.parse(text.slice(jsonStart, jsonEnd + 1)) as {
        pageType?: string;
        script?: string;
        panels: Array<{
          number: number;
          shot: string;
          camera: string;
          action: string;
          description: string;
          dialogue?: string;
          speaker?: string;
          caption?: string;
          sfx?: string;
        }>;
      };
      return { ok: true as const, plan, model: data.model ?? "openai" };
    } catch {
      return { ok: false as const, error: "Could not parse director JSON" };
    }
  });

export const writeStory = createServerFn({ method: "POST" })
  .validator((input: { bible: string; current: string; instruction: string; model?: TextModel }) => input)
  .handler(async ({ data }) => {
    const result = await freeChat({
      model: data.model ?? "openai",
      system:
        "You are the story editor for WATCHERS. Write tight comic-script prose. No markdown headings. Stay inside the bible.",
      user: `BIBLE:\n${data.bible}\n\nCURRENT STORY:\n${data.current}\n\nINSTRUCTION:\n${data.instruction}`,
    });
    if (!result.ok) return result;
    return { ok: true as const, text: result.text, model: data.model ?? "openai" };
  });

export const generatePanelArt = createServerFn({ method: "POST" })
  .validator(
    (input: {
      prompt: string;
      model?: ImageModel;
      width?: number;
      height?: number;
      seed?: number;
    }) => input,
  )
  .handler(async ({ data }) => {
    const seed = data.seed ?? Math.floor(Math.random() * 1_000_000);
    const model = data.model ?? "flux";
    const url = buildFreeImageUrl({
      prompt: data.prompt,
      model,
      width: data.width,
      height: data.height,
      seed,
    });
    try {
      const res = await fetch(url, { method: "GET" });
      if (!res.ok) return { ok: false as const, error: `Free image model ${res.status}` };
    } catch {
      // URL is still usable in <img>; generation happens on first browser request.
    }
    return { ok: true as const, url, model, seed };
  });
