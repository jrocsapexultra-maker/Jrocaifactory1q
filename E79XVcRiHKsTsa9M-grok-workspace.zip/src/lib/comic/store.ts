import { create } from "zustand";
import { persist } from "zustand/middleware";
import { WATCHERS } from "./seed";
import type {
  CharacterDNA,
  ComicPage,
  ContinuityEvent,
  Generation,
  GenerationJob,
  LocationDNA,
  Panel,
  PropItem,
  Universe,
} from "./types";
import { buildContinuityState } from "./continuity";

function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}

interface FactoryState {
  universe: Universe;
  selectedPageId: string;
  selectedCharacterId: string;
  imageModel: "flux" | "turbo";
  textModel: "openai" | "openai-fast";
  resetUniverse: () => void;
  setModels: (image: "flux" | "turbo", text: "openai" | "openai-fast") => void;
  setStory: (story: string) => void;
  updateBible: (patch: Partial<Universe["bible"]>) => void;
  updateStyle: (patch: Partial<Universe["style"]>) => void;
  upsertCharacter: (c: CharacterDNA) => void;
  upsertLocation: (l: LocationDNA) => void;
  upsertProp: (p: PropItem) => void;
  selectPage: (id: string) => void;
  selectCharacter: (id: string) => void;
  updatePage: (id: string, patch: Partial<ComicPage>) => void;
  updatePanel: (pageId: string, panelId: string, patch: Partial<Panel>) => void;
  addEvent: (e: Omit<ContinuityEvent, "id">) => void;
  applyDirectorPlan: (pageId: string, panels: Panel[], type?: ComicPage["type"], script?: string) => void;
  addGeneration: (g: Generation) => void;
  selectGeneration: (pageId: string, panelId: string, genId: string) => void;
  enqueueJob: (job: Omit<GenerationJob, "id" | "createdAt">) => string;
  patchJob: (id: string, patch: Partial<GenerationJob>) => void;
  setPageStatus: (id: string, status: ComicPage["status"]) => void;
  toggleQc: (pageId: string, key: keyof ComicPage["qc"]) => void;
}

export const useFactory = create<FactoryState>()(
  persist(
    (set, get) => ({
      universe: WATCHERS,
      selectedPageId: "p-05",
      selectedCharacterId: "watcher",
      imageModel: "flux",
      textModel: "openai",
      resetUniverse: () =>
        set({
          universe: WATCHERS,
          selectedPageId: "p-05",
          selectedCharacterId: "watcher",
          imageModel: "flux",
          textModel: "openai",
        }),
      setModels: (imageModel, textModel) => set({ imageModel, textModel }),
      setStory: (story) => set({ universe: { ...get().universe, story } }),
      updateBible: (patch) =>
        set({
          universe: { ...get().universe, bible: { ...get().universe.bible, ...patch } },
        }),
      updateStyle: (patch) =>
        set({
          universe: { ...get().universe, style: { ...get().universe.style, ...patch } },
        }),
      upsertCharacter: (c) => {
        const chars = get().universe.characters;
        const i = chars.findIndex((x) => x.id === c.id);
        const next = i >= 0 ? chars.map((x) => (x.id === c.id ? c : x)) : [...chars, c];
        set({ universe: { ...get().universe, characters: next } });
      },
      upsertLocation: (l) => {
        const list = get().universe.locations;
        const i = list.findIndex((x) => x.id === l.id);
        const next = i >= 0 ? list.map((x) => (x.id === l.id ? l : x)) : [...list, l];
        set({ universe: { ...get().universe, locations: next } });
      },
      upsertProp: (p) => {
        const list = get().universe.props;
        const i = list.findIndex((x) => x.id === p.id);
        const next = i >= 0 ? list.map((x) => (x.id === p.id ? p : x)) : [...list, p];
        set({ universe: { ...get().universe, props: next } });
      },
      selectPage: (id) => set({ selectedPageId: id }),
      selectCharacter: (id) => set({ selectedCharacterId: id }),
      updatePage: (id, patch) =>
        set({
          universe: {
            ...get().universe,
            pages: get().universe.pages.map((p) => (p.id === id ? { ...p, ...patch } : p)),
          },
        }),
      updatePanel: (pageId, panelId, patch) =>
        set({
          universe: {
            ...get().universe,
            pages: get().universe.pages.map((p) =>
              p.id === pageId
                ? { ...p, panels: p.panels.map((n) => (n.id === panelId ? { ...n, ...patch } : n)) }
                : p,
            ),
          },
        }),
      addEvent: (e) =>
        set({
          universe: {
            ...get().universe,
            events: [...get().universe.events, { ...e, id: uid("ev") }],
          },
        }),
      applyDirectorPlan: (pageId, panels, type, script) =>
        set({
          universe: {
            ...get().universe,
            pages: get().universe.pages.map((p) =>
              p.id === pageId
                ? {
                    ...p,
                    panels,
                    type: type ?? p.type,
                    script: script ?? p.script,
                    status: p.status === "empty" ? "storyboard" : p.status,
                    layout: `${panels.length}-grid`,
                  }
                : p,
            ),
          },
        }),
      addGeneration: (g) =>
        set({
          universe: { ...get().universe, generations: [g, ...get().universe.generations] },
        }),
      selectGeneration: (pageId, panelId, genId) => {
        const gen = get().universe.generations.find((g) => g.id === genId);
        set({
          universe: {
            ...get().universe,
            pages: get().universe.pages.map((p) =>
              p.id === pageId
                ? {
                    ...p,
                    panels: p.panels.map((n) =>
                      n.id === panelId ? { ...n, selectedGenerationId: genId } : n,
                    ),
                    finalImage: gen?.image ?? p.finalImage,
                    status: p.status === "generating" ? "review" : p.status,
                  }
                : p,
            ),
          },
        });
      },
      enqueueJob: (job) => {
        const id = uid("job");
        set({
          universe: {
            ...get().universe,
            jobs: [{ ...job, id, createdAt: new Date().toISOString() }, ...get().universe.jobs],
          },
        });
        return id;
      },
      patchJob: (id, patch) =>
        set({
          universe: {
            ...get().universe,
            jobs: get().universe.jobs.map((j) => (j.id === id ? { ...j, ...patch } : j)),
          },
        }),
      setPageStatus: (id, status) =>
        set({
          universe: {
            ...get().universe,
            pages: get().universe.pages.map((p) => (p.id === id ? { ...p, status } : p)),
          },
        }),
      toggleQc: (pageId, key) => {
        if (key === "flags") return;
        set({
          universe: {
            ...get().universe,
            pages: get().universe.pages.map((p) =>
              p.id === pageId ? { ...p, qc: { ...p.qc, [key]: !p.qc[key] } } : p,
            ),
          },
        });
      },
    }),
    { name: "jrocai-factory-v2", skipHydration: true },
  ),
);

export function usePage(id?: string) {
  return useFactory((s) => s.universe.pages.find((p) => p.id === (id ?? s.selectedPageId)));
}

export function useContinuityForPage(pageNumber: number) {
  return useFactory((s) => buildContinuityState(s.universe.events, pageNumber));
}

export function pipelinePercents(u: Universe) {
  const n = u.pages.length || 1;
  const story = u.story.trim() ? 100 : 40;
  const board = Math.round((u.pages.filter((p) => p.status !== "empty").length / n) * 100);
  const art = Math.round(
    (u.pages.filter((p) => ["review", "qc", "approved", "published", "generating"].includes(p.status)).length /
      n) *
      100,
  );
  const cont = Math.round((u.pages.filter((p) => p.qc.continuity).length / n) * 100);
  const letter = Math.round((u.pages.filter((p) => p.qc.lettering).length / n) * 100);
  const pub = Math.round((u.pages.filter((p) => p.status === "published" || p.status === "approved").length / n) * 100);
  return { story, board, art, cont, letter, pub };
}
