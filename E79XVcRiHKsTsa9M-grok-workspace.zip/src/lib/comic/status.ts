import type { PageStatus } from "./types";

export function statusTone(status: PageStatus) {
  switch (status) {
    case "approved":
    case "published":
      return "ok" as const;
    case "qc":
    case "review":
      return "warn" as const;
    case "generating":
      return "ink" as const;
    default:
      return "muted" as const;
  }
}

export function statusMark(status: PageStatus) {
  switch (status) {
    case "approved":
    case "published":
      return "✓";
    case "qc":
      return "!";
    case "generating":
      return "●";
    case "review":
      return "R";
    case "storyboard":
      return "S";
    default:
      return "○";
  }
}
