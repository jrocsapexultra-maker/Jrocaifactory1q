export type PageType =
  | "COVER"
  | "SPLASH"
  | "STANDARD"
  | "DOUBLE_SPLASH"
  | "ACTION"
  | "DIALOGUE"
  | "MONTAGE"
  | "FLASHBACK"
  | "DREAM"
  | "FINAL"
  | "BACK_COVER";

export type PageStatus =
  | "empty"
  | "storyboard"
  | "generating"
  | "review"
  | "qc"
  | "approved"
  | "published";

export type ShotType =
  | "establishing"
  | "wide"
  | "full"
  | "medium"
  | "close"
  | "extreme-close"
  | "over-shoulder"
  | "insert"
  | "bird"
  | "worm";

export type JobStatus = "queued" | "running" | "done" | "failed" | "paused";

export interface CharacterDNA {
  id: string;
  name: string;
  role: string;
  physical: string;
  face: string;
  body: string;
  hair: string;
  eyes: string;
  skin: string;
  costume: string;
  footwear: string;
  accessories: string;
  weapons: string;
  signature: string;
  palette: string;
  personality: string;
  voice: string;
  frontRef?: string;
  sideRef?: string;
  backRef?: string;
}

export interface LocationDNA {
  id: string;
  name: string;
  type: string;
  description: string;
  atmosphere: string;
  lighting: string;
  palette: string;
  landmarks: string;
  image?: string;
}

export interface PropItem {
  id: string;
  name: string;
  owner?: string;
  description: string;
  state: string;
  image?: string;
}

export interface StyleBible {
  name: string;
  line: string;
  color: string;
  lighting: string;
  camera: string;
  lettering: string;
  references: string;
}

export interface UniverseBible {
  title: string;
  logline: string;
  premise: string;
  rules: string[];
  factions: { name: string; note: string }[];
  timeline: { year: string; event: string }[];
}

export interface ContinuityEvent {
  id: string;
  pageNumber: number;
  characterId?: string;
  field:
    | "costume"
    | "injuries"
    | "weapons"
    | "props"
    | "vehicles"
    | "location"
    | "weather"
    | "timeOfDay"
    | "damage"
    | "position";
  value: string;
  note?: string;
}

export interface ContinuityState {
  costume: Record<string, string>;
  injuries: Record<string, string>;
  weapons: Record<string, string>;
  props: string[];
  vehicles: string[];
  location: string;
  weather: string;
  timeOfDay: string;
  damage: string;
  position: Record<string, string>;
}

export interface Panel {
  id: string;
  number: number;
  shot: ShotType;
  camera: string;
  action: string;
  description: string;
  dialogue: string;
  speaker?: string;
  caption: string;
  sfx: string;
  prompt: string;
  negative: string;
  selectedGenerationId?: string;
  balloonX: number;
  balloonY: number;
}

export interface Generation {
  id: string;
  panelId: string;
  pageId: string;
  model: string;
  prompt: string;
  image?: string;
  seed?: number;
  status: JobStatus;
  createdAt: string;
  note?: string;
}

export interface QCCheck {
  art: boolean;
  character: boolean;
  continuity: boolean;
  lettering: boolean;
  bleed: boolean;
  flags: string[];
}

export interface ComicPage {
  id: string;
  number: number;
  type: PageType;
  title: string;
  script: string;
  layout: string;
  status: PageStatus;
  finalImage?: string;
  panels: Panel[];
  qc: QCCheck;
}

export interface Chapter {
  id: string;
  title: string;
  synopsis: string;
  pageIds: string[];
}

export interface Volume {
  id: string;
  title: string;
  issue: string;
  pageCount: number;
  chapters: Chapter[];
}

export interface GenerationJob {
  id: string;
  label: string;
  task: string;
  status: JobStatus;
  progress: number;
  pageId?: string;
  panelId?: string;
  createdAt: string;
  error?: string;
}

export interface Universe {
  id: string;
  name: string;
  bible: UniverseBible;
  story: string;
  style: StyleBible;
  characters: CharacterDNA[];
  locations: LocationDNA[];
  props: PropItem[];
  volume: Volume;
  pages: ComicPage[];
  events: ContinuityEvent[];
  generations: Generation[];
  jobs: GenerationJob[];
}
