"""
Art Factory Service
Wraps the free multi-model Art Agent and exposes it to the rest of the Comic Factory.
"""

from __future__ import annotations
import sys
from pathlib import Path
from typing import List, Optional

# Make the copied art_agent importable
ART_AGENT_PATH = Path(__file__).resolve().parents[1] / "agents" / "art_agent"
sys.path.insert(0, str(ART_AGENT_PATH))

from core.models import (
    GenerationRequest as AgentRequest,
    CharacterDNASnippet,
    ContinuityState as AgentContinuity,
    TaskType as AgentTask,
    ModelProvider,
)
from core.router import FreeArtAgent

from app.models.comic import (
    Panel, CharacterDNA, ContinuityState, GenerationJob, GenerationStatus
)


class ArtFactory:
    def __init__(self):
        self.agent = FreeArtAgent()

    async def generate_panel(
        self,
        panel: Panel,
        characters: List[CharacterDNA],
        continuity: Optional[ContinuityState] = None,
        style_bible: Optional[str] = None,
        prefer_local: bool = False,
    ) -> GenerationJob:
        """
        Convert a Panel + DNA + Continuity into a free multi-model generation.
        Returns a GenerationJob record (success or failure).
        """
        # Map to agent request
        dna_snippets = [
            CharacterDNASnippet(
                name=c.name,
                face=c.face,
                body=c.body_proportions,
                hair=c.hair,
                costume=c.costume,
                signature_features=c.signature_features,
                color_palette=c.color_palette,
                reference_image_urls=c.reference_images or [],
            )
            for c in characters if c.id in (panel.character_ids or [c.id for c in characters])
        ]

        agent_cont = None
        if continuity:
            # Flatten first character state for simplicity
            first_char_state = next(iter(continuity.characters.values()), {})
            agent_cont = AgentContinuity(
                costume=first_char_state.get("costume"),
                injuries=first_char_state.get("injury"),
                weapons=first_char_state.get("weapon"),
                location=continuity.location,
                weather=continuity.weather,
                time_of_day=continuity.time_of_day,
            )

        prompt = panel.prompt or panel.description or panel.action or "comic panel"
        req = AgentRequest(
            task=AgentTask.COMIC_PANEL,
            prompt=prompt,
            negative_prompt=panel.negative_prompt or "blurry, deformed, bad anatomy, watermark, text",
            width=1024,
            height=1024,
            characters=dna_snippets,
            continuity=agent_cont,
            style_bible=style_bible,
            require_local=prefer_local,
        )

        result = await self.agent.generate(req)

        job = GenerationJob(
            panel_id=panel.id,
            task="comic_panel",
            status=GenerationStatus.SUCCESS if result.success else GenerationStatus.FAILED,
            provider=result.provider.value if result.provider else None,
            model=result.model_name,
            prompt=prompt,
            negative_prompt=req.negative_prompt,
            seed=result.seed_used,
            output_path=result.image_path,
            error=result.error,
            metadata=result.metadata or {},
        )
        return job

    async def health(self) -> dict:
        return await self.agent.health_check()
