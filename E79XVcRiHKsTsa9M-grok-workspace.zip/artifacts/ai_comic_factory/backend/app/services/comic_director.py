"""
Comic Director
Converts story/script → structured pages + panels with camera language.
Outputs validated JSON ready for the Art Factory.
"""

from __future__ import annotations
from typing import List, Optional
from app.models.comic import (
    Page, Panel, PageType, ShotType, CharacterDNA
)


class ComicDirector:
    """
    Lightweight rule-based + promptable director.
    In production, replace the planning logic with an LLM call
    that returns structured JSON matching the schema.
    """

    def plan_page(
        self,
        page_number: int,
        script: str,
        page_type: PageType = PageType.STANDARD,
        characters: Optional[List[CharacterDNA]] = None,
        style_bible: Optional[str] = None,
    ) -> Page:
        """
        Create a Page with sensible default panels from a short script.
        Real implementation should call an LLM and validate the JSON.
        """
        page = Page(
            chapter_id="temp",
            page_number=page_number,
            page_type=page_type,
            script=script,
            status="storyboarded",
        )

        # Simple heuristic panel split for STANDARD pages
        if page_type == PageType.SPLASH or page_type == PageType.COVER:
            panel = Panel(
                page_id=page.id,
                panel_number=1,
                shot_type=ShotType.WIDE if page_type == PageType.COVER else ShotType.FULL,
                description=script,
                prompt=self._build_panel_prompt(script, characters, style_bible, ShotType.WIDE),
            )
            page.panels = [panel]
        else:
            # 3-panel default rhythm
            beats = self._split_beats(script, max_panels=4)
            for i, beat in enumerate(beats, 1):
                shot = self._choose_shot(i, len(beats))
                panel = Panel(
                    page_id=page.id,
                    panel_number=i,
                    shot_type=shot,
                    description=beat,
                    prompt=self._build_panel_prompt(beat, characters, style_bible, shot),
                )
                page.panels.append(panel)

        return page

    def _split_beats(self, script: str, max_panels: int = 4) -> List[str]:
        # Very naive splitter – replace with LLM later
        sentences = [s.strip() for s in script.replace("\n", ". ").split(".") if s.strip()]
        if len(sentences) <= max_panels:
            return sentences or [script]
        # Group into max_panels
        chunk = max(1, len(sentences) // max_panels)
        beats = []
        for i in range(0, len(sentences), chunk):
            beats.append(". ".join(sentences[i:i+chunk]))
        return beats[:max_panels]

    def _choose_shot(self, panel_idx: int, total: int) -> ShotType:
        if panel_idx == 1:
            return ShotType.WIDE
        if panel_idx == total:
            return ShotType.CLOSE_UP
        return ShotType.MEDIUM

    def _build_panel_prompt(
        self,
        description: str,
        characters: Optional[List[CharacterDNA]],
        style_bible: Optional[str],
        shot: ShotType,
    ) -> str:
        parts = [description, f"shot: {shot.value}"]
        if style_bible:
            parts.append(f"style: {style_bible}")
        if characters:
            for c in characters:
                parts.append(f"Character [{c.name}]: {c.to_prompt_snippet()}")
        return ". ".join(parts)
