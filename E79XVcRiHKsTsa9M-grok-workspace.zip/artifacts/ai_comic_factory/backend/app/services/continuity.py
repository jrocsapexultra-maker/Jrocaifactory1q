"""
Continuity Engine
Tracks costume, injuries, weapons, location, weather across pages.
buildContinuityState(volume_id, page_number) returns the canonical state.
"""

from __future__ import annotations
from typing import Dict, List, Optional
from app.models.comic import ContinuityEvent, ContinuityState


class ContinuityEngine:
    def __init__(self):
        # In-memory for free edition. Replace with DB later.
        self.events: List[ContinuityEvent] = []

    def add_event(self, event: ContinuityEvent) -> ContinuityEvent:
        self.events.append(event)
        return event

    def build_state(self, volume_id: str, page_number: int) -> ContinuityState:
        """
        Return the most recent applicable state for every tracked field
        up to (and including) the given page_number.
        """
        relevant = [
            e for e in self.events
            if e.volume_id == volume_id and e.page_number <= page_number
        ]
        # Sort so later pages override earlier ones
        relevant.sort(key=lambda e: e.page_number)

        state = ContinuityState(page_number=page_number)
        char_states: Dict[str, dict] = {}
        props: Dict[str, str] = {}

        for ev in relevant:
            if ev.entity_type == "character":
                if ev.entity_id not in char_states:
                    char_states[ev.entity_id] = {}
                char_states[ev.entity_id][ev.field] = ev.value
            elif ev.entity_type == "location":
                if ev.field == "name":
                    state.location = ev.value
                elif ev.field == "weather":
                    state.weather = ev.value
                elif ev.field == "time_of_day":
                    state.time_of_day = ev.value
            elif ev.entity_type == "prop":
                props[ev.entity_id] = ev.value

            if ev.notes:
                state.notes.append(f"p{ev.page_number}: {ev.notes}")

        state.characters = char_states
        state.props = props
        return state

    def flag_conflicts(self, volume_id: str, page_number: int, proposed: dict) -> List[str]:
        """
        Compare a proposed generation against current continuity.
        Returns list of human-readable conflict messages.
        """
        current = self.build_state(volume_id, page_number)
        conflicts = []

        for char_id, fields in proposed.get("characters", {}).items():
            known = current.characters.get(char_id, {})
            for field, value in fields.items():
                if field in known and known[field] != value:
                    conflicts.append(
                        f"Character {char_id}.{field}: continuity has '{known[field]}' "
                        f"but prompt proposes '{value}'"
                    )
        return conflicts
