"""
Free Multi-Model Router + Art Agent
Prioritizes fully free local ComfyUI → Pollinations (unlimited) → HF free tier.
Designed for JROCAI Factory Art Factory.
"""

from __future__ import annotations
import asyncio
import logging
from pathlib import Path
from typing import Dict, List, Optional

from core.models import (
    AgentConfig,
    GenerationRequest,
    GenerationResult,
    ModelProvider,
    TaskType,
)
from adapters.comfyui import ComfyUIAdapter
from adapters.pollinations import PollinationsAdapter
from adapters.huggingface import HuggingFaceAdapter
from adapters.base import BaseImageAdapter

logger = logging.getLogger("jrocai.art_agent")


class FreeArtAgent:
    """
    Multi-model free AI agent for comic art generation.
    Usage:
        agent = FreeArtAgent()
        result = await agent.generate(request)
    """

    def __init__(self, config: Optional[AgentConfig] = None):
        self.config = config or AgentConfig()
        Path(self.config.output_dir).mkdir(parents=True, exist_ok=True)

        # Register free adapters
        self.adapters: Dict[ModelProvider, BaseImageAdapter] = {
            ModelProvider.COMFYUI_LOCAL: ComfyUIAdapter(
                base_url=self.config.comfyui_url,
                timeout=self.config.comfyui_timeout,
                output_dir=self.config.output_dir,
            ),
            ModelProvider.POLLINATIONS: PollinationsAdapter(
                base_url=self.config.pollinations_base,
                output_dir=self.config.output_dir,
            ),
            ModelProvider.HUGGINGFACE: HuggingFaceAdapter(
                token=self.config.huggingface_token,
                output_dir=self.config.output_dir,
            ),
        }

        # Task → preferred provider order (can be overridden)
        self.task_preferences: Dict[TaskType, List[ModelProvider]] = {
            TaskType.COMIC_PANEL: [
                ModelProvider.COMFYUI_LOCAL,   # needs ControlNet + DNA
                ModelProvider.POLLINATIONS,
                ModelProvider.HUGGINGFACE,
            ],
            TaskType.CHARACTER_SHEET: [
                ModelProvider.COMFYUI_LOCAL,
                ModelProvider.HUGGINGFACE,
                ModelProvider.POLLINATIONS,
            ],
            TaskType.ENVIRONMENT: [
                ModelProvider.COMFYUI_LOCAL,
                ModelProvider.POLLINATIONS,
                ModelProvider.HUGGINGFACE,
            ],
            TaskType.COVER: [
                ModelProvider.COMFYUI_LOCAL,
                ModelProvider.POLLINATIONS,
            ],
            TaskType.GENERAL: self.config.default_provider_order,
        }

    async def generate(self, request: GenerationRequest) -> GenerationResult:
        """Route the request to the best available free provider."""
        order = self._resolve_order(request)
        last_error = "No providers available"

        for provider in order:
            adapter = self.adapters.get(provider)
            if not adapter:
                continue

            available = await adapter.is_available()
            if not available:
                logger.info(f"Provider {provider} not available, skipping")
                continue

            logger.info(f"Trying free provider: {provider.value} for task {request.task}")
            result = await adapter.generate(request)

            if result.success:
                logger.info(f"Success with {provider.value} in {result.generation_time_sec}s")
                return result

            last_error = result.error or "Unknown error"
            logger.warning(f"{provider.value} failed: {last_error}")

            if self.config.max_retries <= 0:
                break

        return GenerationResult(
            request_id=request.id,
            provider=ModelProvider.MOCK,
            model_name="none",
            success=False,
            error=f"All free providers failed. Last error: {last_error}",
        )

    def _resolve_order(self, request: GenerationRequest) -> List[ModelProvider]:
        if request.require_local:
            return [ModelProvider.COMFYUI_LOCAL]
        if request.preferred_provider:
            # Put preferred first, then the rest
            rest = [p for p in self.config.default_provider_order if p != request.preferred_provider]
            return [request.preferred_provider] + rest
        return self.task_preferences.get(request.task, self.config.default_provider_order)

    async def batch_generate(self, requests: List[GenerationRequest], max_concurrent: int = 2) -> List[GenerationResult]:
        """Simple concurrent batch for Production Queue."""
        semaphore = asyncio.Semaphore(max_concurrent)

        async def _run(req: GenerationRequest) -> GenerationResult:
            async with semaphore:
                return await self.generate(req)

        return await asyncio.gather(*[_run(r) for r in requests])

    async def health_check(self) -> Dict[str, bool]:
        """Return availability of every free provider."""
        status = {}
        for name, adapter in self.adapters.items():
            status[name.value] = await adapter.is_available()
        return status
