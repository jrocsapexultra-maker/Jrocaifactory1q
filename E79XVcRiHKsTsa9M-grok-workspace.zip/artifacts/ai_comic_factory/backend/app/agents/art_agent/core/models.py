"""
Data models for the Free Multi-Model Art Agent.
Designed to plug into JROCAI Factory Elite (Character DNA, Continuity, Generation Jobs).
"""

from __future__ import annotations
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from datetime import datetime
import uuid


class TaskType(str, Enum):
    COMIC_PANEL = "comic_panel"
    CHARACTER_SHEET = "character_sheet"
    ENVIRONMENT = "environment"
    INPAINT = "inpaint"
    UPSCALE = "upscale"
    STORYBOARD = "storyboard"
    COVER = "cover"
    GENERAL = "general"


class ModelProvider(str, Enum):
    COMFYUI_LOCAL = "comfyui_local"      # Fully free, best quality + ControlNet
    POLLINATIONS = "pollinations"        # Unlimited free, no key
    HUGGINGFACE = "huggingface"          # Free tier (rate limited)
    MOCK = "mock"                        # For testing without GPU/API


class ControlNetConfig(BaseModel):
    enabled: bool = False
    type: str = "openpose"               # openpose | depth | canny | lineart | scribble
    weight: float = 0.8
    start_percent: float = 0.0
    end_percent: float = 0.8
    reference_image_path: Optional[str] = None
    preprocessor: Optional[str] = None


class CharacterDNASnippet(BaseModel):
    """Minimal Character DNA injection for prompts."""
    name: str
    face: Optional[str] = None
    body: Optional[str] = None
    hair: Optional[str] = None
    costume: Optional[str] = None
    signature_features: Optional[str] = None
    color_palette: Optional[str] = None
    reference_image_urls: List[str] = Field(default_factory=list)


class ContinuityState(BaseModel):
    costume: Optional[str] = None
    injuries: Optional[str] = None
    weapons: Optional[str] = None
    location: Optional[str] = None
    weather: Optional[str] = None
    time_of_day: Optional[str] = None
    notes: Optional[str] = None


class GenerationRequest(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    task: TaskType = TaskType.COMIC_PANEL
    prompt: str
    negative_prompt: str = "blurry, low quality, deformed, bad anatomy, watermark, text"
    width: int = 1024
    height: int = 1024
    seed: Optional[int] = None
    steps: int = 25
    cfg: float = 7.0

    # JROCAI Elite integrations
    characters: List[CharacterDNASnippet] = Field(default_factory=list)
    continuity: Optional[ContinuityState] = None
    style_bible: Optional[str] = None          # e.g. "manga, high contrast, dynamic lines"
    controlnet: Optional[ControlNetConfig] = None
    reference_images: List[str] = Field(default_factory=list)

    # Routing preferences
    preferred_provider: Optional[ModelProvider] = None
    require_local: bool = False                # Force ComfyUI only
    priority: int = 5                          # 1=highest


class GenerationResult(BaseModel):
    request_id: str
    provider: ModelProvider
    model_name: str
    success: bool
    image_path: Optional[str] = None
    image_url: Optional[str] = None
    error: Optional[str] = None
    seed_used: Optional[int] = None
    generation_time_sec: Optional[float] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class AgentConfig(BaseModel):
    """Global agent configuration – all free by default."""
    comfyui_url: str = "http://127.0.0.1:8188"
    comfyui_timeout: int = 300
    pollinations_base: str = "https://image.pollinations.ai/prompt"
    huggingface_token: Optional[str] = None     # optional free HF token
    default_provider_order: List[ModelProvider] = Field(
        default_factory=lambda: [
            ModelProvider.COMFYUI_LOCAL,
            ModelProvider.POLLINATIONS,
            ModelProvider.HUGGINGFACE,
        ]
    )
    output_dir: str = "./outputs"
    max_retries: int = 2
