#!/usr/bin/env python3
"""
JROCAI Factory – Free Multi-Model Art Agent
===========================================
Fully free AI agent that routes comic art generation across:
  1. Local ComfyUI (best quality + ControlNet + Character DNA)
  2. Pollinations.ai (unlimited, no key)
  3. Hugging Face free Inference API (optional token)

Designed to plug into the Elite architecture (Character DNA, Continuity Engine, Production Queue).

Usage examples at the bottom.
"""

from __future__ import annotations
import asyncio
import json
import logging
import os
from pathlib import Path

from dotenv import load_dotenv

from core.models import (
    AgentConfig,
    CharacterDNASnippet,
    ContinuityState,
    ControlNetConfig,
    GenerationRequest,
    ModelProvider,
    TaskType,
)
from core.router import FreeArtAgent

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("jrocai")


async def main_demo():
    """Quick demo of the free multi-model agent."""
    config = AgentConfig(
        comfyui_url=os.getenv("COMFYUI_URL", "http://127.0.0.1:8188"),
        huggingface_token=os.getenv("HF_TOKEN"),  # optional free token
        output_dir="./outputs",
    )

    agent = FreeArtAgent(config)

    # Health check
    print("\n=== Free Provider Health Check ===")
    health = await agent.health_check()
    for provider, ok in health.items():
        status = "✅ AVAILABLE" if ok else "❌ offline / no token"
        print(f"  {provider:20s} → {status}")

    # Example 1: Simple comic panel with Character DNA + Continuity
    print("\n=== Generating Comic Panel (free multi-model) ===")
    request = GenerationRequest(
        task=TaskType.COMIC_PANEL,
        prompt=(
            "dramatic low-angle comic panel, hero leaping over debris, "
            "rain-soaked city street, dynamic motion lines, high contrast ink"
        ),
        negative_prompt="blurry, photorealistic, 3d render, watermark, text, deformed hands",
        width=1024,
        height=1536,  # comic page ratio-ish
        steps=28,
        cfg=7.5,
        seed=42,
        style_bible="western comic, bold inks, limited color palette, dramatic lighting",
        characters=[
            CharacterDNASnippet(
                name="WATCHER",
                face="sharp jaw, intense dark eyes, short black hair with silver streak",
                body="athletic, tall, broad shoulders",
                hair="short black with silver streak",
                costume="black tactical suit with damaged shoulder plating",
                signature_features="glowing blue left eye, scar across right cheek",
                color_palette="black, silver, electric blue accents",
            )
        ],
        continuity=ContinuityState(
            costume="Damaged V2 – left shoulder plating cracked",
            injuries="bleeding cut on left forearm",
            weapons="plasma rifle holstered on back",
            location="Sector 7 industrial district",
            weather="heavy rain, night",
            time_of_day="02:17",
        ),
        controlnet=ControlNetConfig(
            enabled=True,
            type="openpose",
            weight=0.85,
            end_percent=0.75,
        ),
        # preferred_provider=ModelProvider.POLLINATIONS,  # force a specific free provider
        # require_local=True,  # only use ComfyUI
    )

    result = await agent.generate(request)

    print("\n=== Result ===")
    print(json.dumps(result.model_dump(), indent=2, default=str))

    if result.success:
        print(f"\n✅ Art generated successfully via {result.provider.value}")
        print(f"   Image: {result.image_path or result.image_url}")
        print(f"   Time:  {result.generation_time_sec}s")
    else:
        print(f"\n❌ Generation failed: {result.error}")
        print("   Tip: Start ComfyUI locally for best results, or the agent will fall back to Pollinations.")


if __name__ == "__main__":
    asyncio.run(main_demo())
