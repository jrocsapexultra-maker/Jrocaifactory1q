# JROCAI Factory – Free Multi-Model Art Agent

A **completely free** multi-model AI agent for building comic art inside the Elite JROCAI Factory architecture.

## Features

- **Multi-model routing** (free-first)
  1. **Local ComfyUI** – highest quality, full ControlNet + LoRA + IP-Adapter + Character DNA support (recommended)
  2. **Pollinations.ai** – unlimited, no API key required
  3. **Hugging Face Inference API** – free tier (optional free token)
- Automatic **Character DNA** injection into every prompt
- **Continuity state** injection (costume, injuries, weapons, weather, location…)
- Task-aware routing (`comic_panel`, `character_sheet`, `environment`, `cover`…)
- ControlNet configuration ready for ComfyUI workflows
- Simple batch generation for the Production Queue
- Zero paid services required

## Quick Start

```bash
cd jrocai_art_agent
python -m venv .venv
source .venv/bin/activate   # or .venv\Scripts\activate on Windows
pip install -r requirements.txt

# Optional: free Hugging Face token
export HF_TOKEN=hf_xxxxxxxx

# Optional: point to your local ComfyUI
export COMFYUI_URL=http://127.0.0.1:8188

python agent.py
```

## Recommended Setup for Best Quality (still free)

1. Install [ComfyUI](https://github.com/comfyanonymous/ComfyUI)
2. Download free open checkpoints (SDXL, Pony, Illustrious, Qwen-Image, Flux-schnell, Z-Image, etc.)
3. Install ControlNet models + `comfyui_controlnet_aux`
4. Run ComfyUI → the agent will automatically prefer it

When ComfyUI is offline the agent silently falls back to Pollinations (still free).

## Integration with Elite Architecture

```python
from core.models import GenerationRequest, CharacterDNASnippet, ContinuityState, TaskType
from core.router import FreeArtAgent

agent = FreeArtAgent()

req = GenerationRequest(
    task=TaskType.COMIC_PANEL,
    prompt="hero leaps across rooftops under lightning",
    characters=[CharacterDNASnippet(name="WATCHER", face="...", costume="...")],
    continuity=ContinuityState(costume="Damaged V2", weather="storm"),
    style_bible="high-contrast western comic ink",
)

result = await agent.generate(req)
```

## Directory Layout

```
jrocai_art_agent/
├── agent.py              # Demo entry point
├── core/
│   ├── models.py         # Pydantic models (DNA, Continuity, Jobs)
│   └── router.py         # Free multi-model router
├── adapters/
│   ├── base.py
│   ├── comfyui.py        # Local free (best)
│   ├── pollinations.py   # Unlimited free cloud
│   └── huggingface.py    # Free tier
├── workflows/            # Drop real ComfyUI workflow JSONs here
├── examples/
└── requirements.txt
```

## Next Steps for Full Elite Integration

- Replace the basic ComfyUI workflow with full ControlNet + IP-Adapter + Character LoRA graphs
- Wire Generation Jobs into the Production Queue
- Add Continuity Guardian checks before routing
- Cache preprocessed ControlNet maps
- Expose the agent as an API endpoint for the frontend

All core components remain free and open.
```
