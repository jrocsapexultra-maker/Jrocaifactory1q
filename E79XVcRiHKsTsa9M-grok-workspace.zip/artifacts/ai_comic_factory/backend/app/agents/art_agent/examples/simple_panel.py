"""Minimal example – generate one comic panel with free multi-model agent."""

import asyncio
import sys
sys.path.insert(0, "..")

from core.models import GenerationRequest, CharacterDNASnippet, TaskType
from core.router import FreeArtAgent


async def main():
    agent = FreeArtAgent()

    req = GenerationRequest(
        task=TaskType.COMIC_PANEL,
        prompt="full-body shot of a cyberpunk detective standing in neon rain, dramatic lighting",
        characters=[
            CharacterDNASnippet(
                name="KIRA",
                face="sharp features, cybernetic left eye",
                costume="long black coat, high collar",
            )
        ],
        style_bible="manga, high contrast, detailed linework",
        width=768,
        height=1152,
    )

    result = await agent.generate(req)
    print(result)


if __name__ == "__main__":
    asyncio.run(main())
