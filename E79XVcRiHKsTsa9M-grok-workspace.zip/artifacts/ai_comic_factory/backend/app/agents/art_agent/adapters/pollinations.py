"""
Pollinations.ai Adapter – completely free, no API key required.
Unlimited for personal use. Good fallback when local ComfyUI is offline.
Supports simple txt2img. No ControlNet / LoRA (use for drafts or when GPU unavailable).
"""

from __future__ import annotations
import time
from pathlib import Path
from urllib.parse import quote

import httpx

from adapters.base import BaseImageAdapter
from core.models import GenerationRequest, GenerationResult, ModelProvider


class PollinationsAdapter(BaseImageAdapter):
    provider = ModelProvider.POLLINATIONS

    def __init__(self, base_url: str = "https://image.pollinations.ai/prompt", output_dir: str = "./outputs"):
        super().__init__()
        self.base_url = base_url
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    async def is_available(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=8.0) as client:
                # Simple HEAD or lightweight check
                r = await client.get("https://pollinations.ai", follow_redirects=True)
                return r.status_code < 500
        except Exception:
            return False

    async def generate(self, request: GenerationRequest) -> GenerationResult:
        start = time.time()
        prompt = self.build_enriched_prompt(request)

        # Pollinations URL format: /prompt/{prompt}?width=..&height=..&seed=..&nologo=true
        encoded = quote(prompt[:1500])  # keep reasonable length
        params = {
            "width": request.width,
            "height": request.height,
            "nologo": "true",
            "enhance": "true",
        }
        if request.seed is not None:
            params["seed"] = request.seed

        query = "&".join(f"{k}={v}" for k, v in params.items())
        url = f"{self.base_url}/{encoded}?{query}"

        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                r = await client.get(url)
                if r.status_code != 200:
                    return GenerationResult(
                        request_id=request.id,
                        provider=self.provider,
                        model_name="pollinations",
                        success=False,
                        error=f"HTTP {r.status_code}",
                    )

                out_path = self.output_dir / f"pollinations_{request.id[:8]}.png"
                out_path.write_bytes(r.content)

                return GenerationResult(
                    request_id=request.id,
                    provider=self.provider,
                    model_name="pollinations-free",
                    success=True,
                    image_path=str(out_path),
                    image_url=url,
                    seed_used=request.seed,
                    generation_time_sec=round(time.time() - start, 2),
                    metadata={"source": "pollinations.ai"},
                )
        except Exception as e:
            return GenerationResult(
                request_id=request.id,
                provider=self.provider,
                model_name="pollinations-free",
                success=False,
                error=str(e),
                generation_time_sec=round(time.time() - start, 2),
            )
