"""Base adapter interface for free multi-model routing."""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Optional
from core.models import GenerationRequest, GenerationResult, ModelProvider


class BaseImageAdapter(ABC):
    provider: ModelProvider

    def __init__(self, config: dict | None = None):
        self.config = config or {}

    @abstractmethod
    async def is_available(self) -> bool:
        """Return True if this free provider can be used right now."""
        ...

    @abstractmethod
    async def generate(self, request: GenerationRequest) -> GenerationResult:
        """Execute generation. Must never require paid API keys for basic use."""
        ...

    def build_enriched_prompt(self, request: GenerationRequest) -> str:
        """Inject Character DNA + Continuity + Style Bible into the prompt."""
        parts = [request.prompt.strip()]

        if request.style_bible:
            parts.append(f"Style: {request.style_bible}")

        for char in request.characters:
            dna = f"{char.name}"
            if char.face:
                dna += f", face: {char.face}"
            if char.body:
                dna += f", body: {char.body}"
            if char.hair:
                dna += f", hair: {char.hair}"
            if char.costume:
                dna += f", wearing: {char.costume}"
            if char.signature_features:
                dna += f", signature: {char.signature_features}"
            if char.color_palette:
                dna += f", colors: {char.color_palette}"
            parts.append(f"Character DNA [{char.name}]: {dna}")

        if request.continuity:
            cont = []
            if request.continuity.costume:
                cont.append(f"costume state: {request.continuity.costume}")
            if request.continuity.injuries:
                cont.append(f"injuries: {request.continuity.injuries}")
            if request.continuity.weapons:
                cont.append(f"weapons: {request.continuity.weapons}")
            if request.continuity.location:
                cont.append(f"location: {request.continuity.location}")
            if request.continuity.weather:
                cont.append(f"weather: {request.continuity.weather}")
            if request.continuity.time_of_day:
                cont.append(f"time: {request.continuity.time_of_day}")
            if cont:
                parts.append("Continuity: " + "; ".join(cont))

        return ". ".join(parts)
