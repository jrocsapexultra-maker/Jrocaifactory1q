"""
Hugging Face Inference API Adapter – free tier (rate-limited).
Requires a free HF token (read access). Good for open models when local GPU is unavailable.
"""

from __future__ import annotations
import time
from pathlib import Path
from typing import Optional

import httpx

from adapters.base import BaseImageAdapter
from core.models import GenerationRequest, GenerationResult, ModelProvider


class HuggingFaceAdapter(BaseImageAdapter):
    provider = ModelProvider.HUGGINGFACE

    # Popular free / open image models that often work on the free Inference API
    DEFAULT_MODEL = "stabilityai/stable-diffusion-xl-base-1.0"
    # Alternatives: "black-forest-labs/FLUX.1-schnell", "Qwen/Qwen-Image", etc. (availability varies)

    def __init__(
        self,
        token: Optional[str] = None,
        model: str = DEFAULT_MODEL,
        output_dir: str = "./outputs",
    ):
        super().__init__()
        self.token = token
        self.model = model
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.api_url = f"https://api-inference.huggingface.co/models/{model}"

    async def is_available(self) -> bool:
        if not self.token:
            return False
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                r = await client.get(
                    self.api_url,
                    headers={"Authorization": f"Bearer {self.token}"},
                )
                # 200 or 503 (model loading) both mean the endpoint is reachable
                return r.status_code in (200, 503)
        except Exception:
            return False

    async def generate(self, request: GenerationRequest) -> GenerationResult:
        if not self.token:
            return GenerationResult(
                request_id=request.id,
                provider=self.provider,
                model_name=self.model,
                success=False,
                error="No Hugging Face token provided (free token required)",
            )

        start = time.time()
        prompt = self.build_enriched_prompt(request)

        payload = {
            "inputs": prompt,
            "parameters": {
                "negative_prompt": request.negative_prompt,
                "width": min(request.width, 1024),
                "height": min(request.height, 1024),
                "num_inference_steps": min(request.steps, 30),
                "guidance_scale": request.cfg,
            },
        }
        if request.seed is not None:
            payload["parameters"]["seed"] = request.seed

        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }

        try:
            async with httpx.AsyncClient(timeout=180.0) as client:
                r = await client.post(self.api_url, json=payload, headers=headers)

                if r.status_code == 503:
                    # Model is loading – wait and retry once
                    await asyncio.sleep(15)
                    r = await client.post(self.api_url, json=payload, headers=headers)

                if r.status_code != 200:
                    return GenerationResult(
                        request_id=request.id,
                        provider=self.provider,
                        model_name=self.model,
                        success=False,
                        error=f"HF API {r.status_code}: {r.text[:300]}",
                    )

                out_path = self.output_dir / f"hf_{request.id[:8]}.png"
                out_path.write_bytes(r.content)

                return GenerationResult(
                    request_id=request.id,
                    provider=self.provider,
                    model_name=self.model,
                    success=True,
                    image_path=str(out_path),
                    seed_used=request.seed,
                    generation_time_sec=round(time.time() - start, 2),
                    metadata={"hf_model": self.model},
                )
        except Exception as e:
            return GenerationResult(
                request_id=request.id,
                provider=self.provider,
                model_name=self.model,
                success=False,
                error=str(e),
                generation_time_sec=round(time.time() - start, 2),
            )


# needed for the retry sleep
import asyncio
