"""
Core Comic Data Models — Phase 1 of Elite Architecture
Projects → Volumes → Chapters → Pages → Panels
+ Characters (DNA) + Continuity Events + Generation Jobs
"""

from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field
import uuid


# ---------- Enums ----------

class PageType(str, Enum):
    COVER = "cover"
    SPLASH = "splash"
    STANDARD = "standard"
    DOUBLE_SPLASH = "double_splash"
    ACTION = "action"
    DIALOGUE = "dialogue"
    MONTAGE = "montage"
    FLASHBACK = "flashback"
    DREAM = "dream"
    FINAL = "final"
    BACK_COVER = "back_cover"


class PageStatus(str, Enum):
    DRAFT = "draft"
    STORYBOARDED = "storyboarded"
    GENERATING = "generating"
    REVIEW = "review"
    APPROVED = "approved"
    PUBLISHED = "published"


class ShotType(str, Enum):
    EXTREME_WIDE = "extreme_wide"
    WIDE = "wide"
    FULL = "full"
    MEDIUM = "medium"
    CLOSE_UP = "close_up"
    EXTREME_CLOSE = "extreme_close"
    OVER_SHOULDER = "over_shoulder"
    POV = "pov"
    DUTCH = "dutch"


class GenerationStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    SELECTED = "selected"
    REJECTED = "rejected"


# ---------- Character DNA ----------

class CharacterDNA(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    physical_description: Optional[str] = None
    face: Optional[str] = None
    body_proportions: Optional[str] = None
    hair: Optional[str] = None
    eyes: Optional[str] = None
    skin: Optional[str] = None
    costume: Optional[str] = None
    footwear: Optional[str] = None
    accessories: Optional[str] = None
    weapons: Optional[str] = None
    signature_features: Optional[str] = None
    color_palette: Optional[str] = None
    personality: Optional[str] = None
    reference_images: List[str] = Field(default_factory=list)  # paths or URLs
    front_reference: Optional[str] = None
    side_reference: Optional[str] = None
    back_reference: Optional[str] = None
    expression_sheet: Optional[str] = None
    pose_sheet: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    def to_prompt_snippet(self) -> str:
        parts = [self.name]
        if self.face:
            parts.append(f"face: {self.face}")
        if self.body_proportions:
            parts.append(f"body: {self.body_proportions}")
        if self.hair:
            parts.append(f"hair: {self.hair}")
        if self.costume:
            parts.append(f"wearing: {self.costume}")
        if self.signature_features:
            parts.append(f"signature: {self.signature_features}")
        if self.color_palette:
            parts.append(f"colors: {self.color_palette}")
        return ", ".join(parts)


# ---------- Continuity ----------

class ContinuityEvent(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    volume_id: str
    page_number: int
    entity_type: str          # "character" | "location" | "prop"
    entity_id: str
    field: str                # "costume" | "injury" | "weapon" | "weather" ...
    value: str
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ContinuityState(BaseModel):
    """Canonical state for a given page (built by Continuity Engine)."""
    page_number: int
    characters: dict = Field(default_factory=dict)  # char_id → {costume, injury, ...}
    location: Optional[str] = None
    weather: Optional[str] = None
    time_of_day: Optional[str] = None
    props: dict = Field(default_factory=dict)
    notes: List[str] = Field(default_factory=list)


# ---------- Core Hierarchy ----------

class Panel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    page_id: str
    panel_number: int
    shot_type: ShotType = ShotType.MEDIUM
    camera_angle: Optional[str] = None
    action: Optional[str] = None
    description: Optional[str] = None
    dialogue: Optional[str] = None
    caption: Optional[str] = None
    sfx: Optional[str] = None
    prompt: Optional[str] = None
    negative_prompt: Optional[str] = None
    selected_generation_id: Optional[str] = None
    character_ids: List[str] = Field(default_factory=list)
    location_id: Optional[str] = None
    controlnet_type: Optional[str] = None
    controlnet_weight: float = 0.8


class Page(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    chapter_id: str
    page_number: int
    page_type: PageType = PageType.STANDARD
    layout: Optional[str] = None          # e.g. "3-panel vertical", "splash"
    script: Optional[str] = None
    status: PageStatus = PageStatus.DRAFT
    final_image_path: Optional[str] = None
    panels: List[Panel] = Field(default_factory=list)
    notes: Optional[str] = None


class Chapter(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    volume_id: str
    chapter_number: int
    title: str
    summary: Optional[str] = None
    pages: List[Page] = Field(default_factory=list)


class Volume(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    volume_number: int
    title: str
    page_count_target: int = 120
    status: str = "planning"
    chapters: List[Chapter] = Field(default_factory=list)


class Project(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: Optional[str] = None
    style_bible: Optional[str] = None
    universe_bible: Optional[str] = None
    characters: List[CharacterDNA] = Field(default_factory=list)
    volumes: List[Volume] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ---------- Generation Job ----------

class GenerationJob(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    panel_id: Optional[str] = None
    page_id: Optional[str] = None
    task: str = "comic_panel"
    status: GenerationStatus = GenerationStatus.QUEUED
    provider: Optional[str] = None
    model: Optional[str] = None
    prompt: str
    negative_prompt: str = ""
    seed: Optional[int] = None
    width: int = 1024
    height: int = 1024
    output_path: Optional[str] = None
    error: Optional[str] = None
    version: int = 1
    is_selected: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)
    finished_at: Optional[datetime] = None
    metadata: dict = Field(default_factory=dict)
