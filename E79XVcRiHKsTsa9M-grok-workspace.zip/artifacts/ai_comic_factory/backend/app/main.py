"""
JROCAI AI Comic Factory — FastAPI entry point
Free multi-model comic production API
"""

from __future__ import annotations
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uuid

from app.models.comic import (
    Project, Volume, Chapter, Page, Panel, CharacterDNA,
    ContinuityEvent, PageType, GenerationJob
)
from app.services.continuity import ContinuityEngine
from app.services.comic_director import ComicDirector
from app.services.art_factory import ArtFactory

app = FastAPI(
    title="JROCAI AI Comic Factory",
    description="Free multi-model AI Comic Production Studio — Elite Architecture",
    version="0.1.0-free",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory stores for the free edition (swap for real DB later)
projects: dict[str, Project] = {}
continuity_engine = ContinuityEngine()
director = ComicDirector()
art_factory = ArtFactory()


# ---------- Health ----------

@app.get("/")
async def root():
    return {
        "name": "JROCAI AI Comic Factory",
        "edition": "Free Elite",
        "status": "online",
        "docs": "/docs",
    }


@app.get("/health")
async def health():
    art_health = await art_factory.health()
    return {
        "api": "ok",
        "art_providers": art_health,
    }


# ---------- Projects ----------

@app.post("/api/projects", response_model=Project)
async def create_project(title: str, description: str = "", style_bible: str = ""):
    proj = Project(title=title, description=description, style_bible=style_bible)
    projects[proj.id] = proj
    return proj


@app.get("/api/projects", response_model=List[Project])
async def list_projects():
    return list(projects.values())


@app.get("/api/projects/{project_id}", response_model=Project)
async def get_project(project_id: str):
    if project_id not in projects:
        raise HTTPException(404, "Project not found")
    return projects[project_id]


# ---------- Characters (DNA) ----------

@app.post("/api/projects/{project_id}/characters", response_model=CharacterDNA)
async def add_character(project_id: str, character: CharacterDNA):
    if project_id not in projects:
        raise HTTPException(404, "Project not found")
    projects[project_id].characters.append(character)
    return character


# ---------- Continuity ----------

@app.post("/api/continuity/events", response_model=ContinuityEvent)
async def add_continuity_event(event: ContinuityEvent):
    return continuity_engine.add_event(event)


@app.get("/api/continuity/{volume_id}/{page_number}")
async def get_continuity_state(volume_id: str, page_number: int):
    return continuity_engine.build_state(volume_id, page_number)


# ---------- Comic Director ----------

class PlanPageRequest(BaseModel):
    page_number: int
    script: str
    page_type: PageType = PageType.STANDARD
    character_ids: List[str] = []
    style_bible: Optional[str] = None


@app.post("/api/director/plan-page", response_model=Page)
async def plan_page(req: PlanPageRequest):
    # Resolve characters if needed (simplified)
    chars = []
    page = director.plan_page(
        page_number=req.page_number,
        script=req.script,
        page_type=req.page_type,
        characters=chars,
        style_bible=req.style_bible,
    )
    return page


# ---------- Art Factory / Generate ----------

class GeneratePanelRequest(BaseModel):
    panel: Panel
    character_ids: List[str] = []
    volume_id: Optional[str] = None
    page_number: int = 1
    style_bible: Optional[str] = None
    prefer_local: bool = False


@app.post("/api/generate/panel", response_model=GenerationJob)
async def generate_panel(req: GeneratePanelRequest):
    # Build continuity
    continuity = None
    if req.volume_id:
        continuity = continuity_engine.build_state(req.volume_id, req.page_number)

    # Resolve characters (simplified – in real app look up from project)
    characters = []

    job = await art_factory.generate_panel(
        panel=req.panel,
        characters=characters,
        continuity=continuity,
        style_bible=req.style_bible,
        prefer_local=req.prefer_local,
    )
    return job


# ---------- Production helpers ----------

@app.post("/api/generate/page/{page_id}")
async def generate_page(page_id: str):
    """Placeholder for full page pipeline (plan → generate all panels → composite)."""
    return {
        "message": "Full page generation pipeline ready for expansion",
        "page_id": page_id,
        "steps": [
            "1. Load page + panels",
            "2. Load Character DNA",
            "3. Build continuity state",
            "4. Queue Art Factory jobs",
            "5. Select generations",
            "6. Lettering",
            "7. Export",
        ],
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
