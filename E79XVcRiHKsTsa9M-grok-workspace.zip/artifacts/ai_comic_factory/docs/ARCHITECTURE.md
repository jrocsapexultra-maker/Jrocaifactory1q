# JROCAI AI Comic Factory — Architecture Overview

## Free Elite Edition

### 1. Data Layer (Phase 1)
- `Project` → `Volume` → `Chapter` → `Page` → `Panel`
- `CharacterDNA` (persistent identity package)
- `ContinuityEvent` + `ContinuityState`
- `GenerationJob` (every image is versioned)

### 2. Continuity Engine
- Tracks costume / injury / weapon / location / weather per page
- `build_state(volume_id, page_number)` returns canonical state
- Conflict flagging before generation

### 3. Comic Director
- Script → structured Page + Panels
- Shot type, camera language, panel rhythm
- Ready for LLM-powered planning (structured JSON)

### 4. Art Factory (Free Multi-Model)
- **Router priority**:
  1. Local ComfyUI (ControlNet + LoRA + IP-Adapter)
  2. Pollinations.ai (unlimited, no key)
  3. Hugging Face free Inference API
- Automatic Character DNA + Continuity injection
- Task-aware routing

### 5. Production Pipeline (ready for expansion)
```
STORY
 → Comic Director (plan pages/panels)
 → Continuity Engine (state)
 → Art Factory (generate)
 → Generation selection
 → Lettering
 → QC
 → Export (PNG / PDF / CBZ)
```

### 6. API Surface (FastAPI)
- `POST /api/projects`
- `POST /api/projects/{id}/characters`
- `POST /api/continuity/events`
- `GET  /api/continuity/{volume}/{page}`
- `POST /api/director/plan-page`
- `POST /api/generate/panel`
- `GET  /health` (shows free provider status)

All core logic is free and local-first.
