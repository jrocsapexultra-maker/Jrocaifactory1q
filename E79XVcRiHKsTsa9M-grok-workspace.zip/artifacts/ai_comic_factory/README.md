# JROCAI AI Comic Factory — Elite (Free Edition)

**Fully free, multi-model AI Comic Production Studio**

A complete open architecture for generating professional comic books with:
- Character DNA lock
- Continuity Engine
- Multi-model Art Factory (ComfyUI + free cloud fallbacks)
- Comic Director (story → pages → panels)
- Production Queue
- Lettering & Export (PNG / PDF / CBZ)

No paid APIs required. Local-first with free cloud fallbacks.

---

## Architecture

```
AI COMIC FACTORY
│
├── AI COMIC STUDIO
│   ├── Universe / Story / Style Bible
│   ├── Character DNA
│   ├── Location DNA
│   └── Prop Library
│
├── STORY ENGINE
│   ├── Story → Chapters → Pages → Panels
│   ├── Dialogue extraction
│   └── Scene continuity
│
├── ART FACTORY (Free Multi-Model)
│   ├── Model Router (ComfyUI local → Pollinations → HF free)
│   ├── ControlNet workflows
│   ├── Character DNA injection
│   └── Batch generation
│
├── CONTINUITY ENGINE
│   ├── Costume / Injury / Weapon / Location state
│   └── Conflict detection
│
├── COMIC DIRECTOR
│   ├── Panel rhythm & camera language
│   ├── Splash / Double-page / Cover support
│
├── LETTERING STUDIO
│   ├── Speech balloons, captions, SFX
│
├── QUALITY CONTROL
│   └── Anatomy / consistency / missing-panel checks
│
├── PRODUCTION QUEUE
│   ├── Batch jobs, retry, pause/resume
│
└── PUBLISHING
    ├── PNG / PDF / CBZ / Print-ready / Web
```

---

## Quick Start (Free)

```bash
cd ai_comic_factory

# Backend
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Optional free keys
export HF_TOKEN=hf_xxx          # free Hugging Face token
export COMFYUI_URL=http://127.0.0.1:8188

# Run the free Art Agent demo
python -m app.agents.art_agent.agent

# Or start the API
uvicorn app.main:app --reload --port 8000
```

For best quality: run **ComfyUI** locally and the factory will automatically prefer it.

---

## Project Structure

```
ai_comic_factory/
├── backend/
│   ├── app/
│   │   ├── main.py                 # FastAPI entry
│   │   ├── api/                    # REST endpoints
│   │   ├── core/                   # Config, database
│   │   ├── models/                 # SQLAlchemy / Pydantic models
│   │   ├── services/               # Business logic
│   │   │   ├── story_engine.py
│   │   │   ├── continuity.py
│   │   │   ├── comic_director.py
│   │   │   ├── production_queue.py
│   │   │   └── exporter.py
│   │   └── agents/
│   │       └── art_agent/          # Free multi-model Art Agent
│   └── workflows/                  # ComfyUI workflow JSONs
├── database/
├── frontend/                       # (placeholder for UI)
├── prompts/                        # System prompts for Director / QC
├── storage/
│   ├── characters/
│   ├── pages/
│   ├── generations/
│   └── exports/
└── docs/
```

---

## Core Principles

1. **Local-first, free-second** — ComfyUI is preferred; free cloud is automatic fallback.
2. **Never delete generations** — every version is kept (v1 rejected, v2 selected…).
3. **Character DNA is injected automatically** — user never pastes descriptions manually.
4. **Continuity is checked before generation**.
5. **Phased upgrades** — existing code is never blindly overwritten.

---

## Next Actions

1. Start ComfyUI + download free open models (SDXL / Pony / Illustrious / Qwen-Image / Flux-schnell…).
2. Run `python -m app.agents.art_agent.agent` to test the free multi-model router.
3. Use the API endpoints under `/api/projects`, `/api/pages/{id}/generate`, etc.
4. Feed the factory a story → let the Comic Director plan pages → generate with the Art Agent.

Built for the Elite Tier vision. 100% free core.
